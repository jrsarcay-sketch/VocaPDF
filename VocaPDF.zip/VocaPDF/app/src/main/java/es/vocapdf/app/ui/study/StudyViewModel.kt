package es.vocapdf.app.ui.study

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import es.vocapdf.app.AppContainer
import es.vocapdf.app.audio.PronunciationFeedback
import es.vocapdf.app.audio.Speaker
import es.vocapdf.app.audio.evaluatePronunciation
import es.vocapdf.app.data.db.Word
import es.vocapdf.app.domain.Gamification
import es.vocapdf.app.domain.Grade
import kotlinx.coroutines.launch

class StudyViewModel(private val container: AppContainer) : ViewModel() {

    enum class Phase { SETUP, LOADING, CARDS, EMPTY, DONE }

    var phase by mutableStateOf(Phase.SETUP); private set
    var deckId by mutableStateOf<Long?>(null)
    var current by mutableStateOf<Word?>(null); private set
    var flipped by mutableStateOf(false)
    var position by mutableIntStateOf(0); private set
    var sessionTotal by mutableIntStateOf(0); private set
    var reviewed by mutableIntStateOf(0); private set
    var correct by mutableIntStateOf(0); private set
    var xpGained by mutableIntStateOf(0); private set
    var goalReachedNow by mutableStateOf(false); private set
    var feedback by mutableStateOf<PronunciationFeedback?>(null)
    var isExtraPractice by mutableStateOf(false); private set

    private val queue = ArrayDeque<Word>()
    private val requeued = HashSet<Long>()
    private var startedAt = 0L
    private var initialized = false

    fun initOnce(initialDeck: Long?) {
        if (initialized) return
        initialized = true
        if (initialDeck != null) { deckId = initialDeck; start() }
    }

    fun start(extra: Boolean = false) {
        phase = Phase.LOADING
        viewModelScope.launch {
            val size = container.settings.current().sessionSize
            val words = if (extra) container.repository.extraPractice(deckId, size)
            else container.repository.studyQueue(deckId, size)
            isExtraPractice = extra
            queue.clear(); requeued.clear()
            queue.addAll(words)
            sessionTotal = words.size
            position = 0; reviewed = 0; correct = 0; xpGained = 0; goalReachedNow = false
            startedAt = System.currentTimeMillis()
            if (words.isEmpty()) {
                phase = Phase.EMPTY
            } else {
                phase = Phase.CARDS
                next()
            }
        }
    }

    private fun next() {
        flipped = false
        feedback = null
        val w = queue.removeFirstOrNull()
        if (w == null) { finish(); return }
        current = w
        position++
        if (container.speaker.status.value == Speaker.Status.READY) {
            viewModelScope.launch {
                if (container.settings.current().autoSpeak) container.speaker.speak(w.english)
            }
        }
    }

    fun speak() { current?.let { container.speaker.speak(it.english) } }
    fun speakSlow() { current?.let { container.speaker.speak(it.english, 0.6f) } }

    fun grade(g: Grade) {
        val w = current ?: return
        reviewed++
        if (g != Grade.AGAIN) correct++
        if (g == Grade.AGAIN && w.id !in requeued) {
            // vuelve a salir al final de la sesión
            requeued += w.id
            queue.addLast(w)
            sessionTotal++
        }
        viewModelScope.launch {
            val out = container.repository.gradeCard(w, g)
            xpGained += out.xpGained
            if (out.goalJustReached) goalReachedNow = true
        }
        next()
    }

    fun onSpeechResult(results: List<String>) {
        val w = current ?: return
        feedback = evaluatePronunciation(w.english, results)
    }

    private fun finish() {
        current = null
        phase = Phase.DONE
        val seconds = (System.currentTimeMillis() - startedAt) / 1000
        viewModelScope.launch { container.repository.addStudyTime(seconds.coerceAtMost(3 * 60 * 60)) }
    }

    fun quit() {
        if (phase == Phase.CARDS && reviewed > 0) finish() else phase = Phase.SETUP
    }

    fun backToSetup() { phase = Phase.SETUP }

    val accuracy: Int get() = if (reviewed == 0) 0 else correct * 100 / reviewed
    val message: String get() = Gamification.sessionMessage(reviewed, accuracy)
}
