package es.vocapdf.app.audio

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import es.vocapdf.app.domain.TextMatch

/** Valoración amable de la pronunciación. */
data class PronunciationFeedback(val emoji: String, val message: String, val heard: String)

fun isSpeechRecognitionAvailable(context: Context): Boolean =
    SpeechRecognizer.isRecognitionAvailable(context) ||
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).resolveActivity(context.packageManager) != null

fun evaluatePronunciation(expected: String, heard: List<String>): PronunciationFeedback {
    if (heard.isEmpty()) return PronunciationFeedback("🎙️", "No te he oído bien. ¡Inténtalo de nuevo!", "")
    val best = heard.maxBy { TextMatch.similarity(it, expected) }
    val score = TextMatch.similarity(best, expected)
    val (emoji, msg) = when {
        score >= 0.9 -> "🎉" to "¡Perfecto! Pronunciación excelente."
        score >= 0.7 -> "👏" to "¡Muy bien! Casi perfecto."
        score >= 0.5 -> "🙂" to "¡Buen intento! Escucha el audio y prueba otra vez."
        else -> "💪" to "Sigue practicando, ¡lo conseguirás!"
    }
    return PronunciationFeedback(emoji, msg, best)
}

/**
 * Devuelve una función que abre el reconocedor de voz del sistema en inglés, o null si
 * el dispositivo no lo admite. Usa el diálogo del sistema, así que la app no necesita
 * pedir el permiso de micrófono.
 */
@Composable
fun rememberSpeechRecognizer(onResult: (List<String>) -> Unit): (() -> Unit)? {
    val context = LocalContext.current
    val available = remember { isSpeechRecognitionAvailable(context) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            onResult(res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty())
        }
    }
    if (!available) return null
    return {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Di la palabra en inglés")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        try {
            launcher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "El reconocimiento de voz no está disponible", Toast.LENGTH_SHORT).show()
        }
    }
}
