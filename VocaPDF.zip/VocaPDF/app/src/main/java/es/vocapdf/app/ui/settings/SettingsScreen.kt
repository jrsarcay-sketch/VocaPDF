package es.vocapdf.app.ui.settings

import android.Manifest
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import es.vocapdf.app.appContainer
import es.vocapdf.app.audio.Speaker
import es.vocapdf.app.data.Settings
import es.vocapdf.app.data.ThemeMode
import es.vocapdf.app.reminders.ReminderScheduler
import es.vocapdf.app.ui.components.BackTopBar
import es.vocapdf.app.ui.components.ChoiceRow
import es.vocapdf.app.ui.components.backupFileName
import es.vocapdf.app.ui.components.rememberCsvActions
import es.vocapdf.app.ui.theme.Bad
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val container = appContainer()
    val repo = container.settings
    val scope = rememberCoroutineScope()
    val s by repo.settings.collectAsStateWithLifecycle(initialValue = Settings())
    val ttsStatus by container.speaker.status.collectAsStateWithLifecycle()
    var rate by remember(s.ttsRate) { mutableFloatStateOf(s.ttsRate) }
    var confirmReset by remember { mutableStateOf(false) }
    val csv = rememberCsvActions()

    fun enableReminders(hour: Int, minute: Int) {
        scope.launch { repo.setReminders(true, hour, minute) }
        ReminderScheduler.schedule(context, hour, minute)
        Toast.makeText(context, "Te recordaremos estudiar a las %02d:%02d".format(hour, minute), Toast.LENGTH_SHORT).show()
    }

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) enableReminders(s.reminderHour, s.reminderMinute)
        else Toast.makeText(context, "Sin permiso de notificaciones no podemos enviarte recordatorios", Toast.LENGTH_LONG).show()
    }

    Scaffold(topBar = { BackTopBar("Ajustes", onBack) }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Section("🎯 Objetivo diario") {
                Text("Palabras a repasar cada día", style = MaterialTheme.typography.bodyMedium)
                ChoiceRow(listOf(5, 10, 20, 30), s.dailyGoal, { "$it" }) { scope.launch { repo.setDailyGoal(it) } }
            }
            Section("🃏 Sesión de repaso") {
                Text("Tarjetas por sesión", style = MaterialTheme.typography.bodyMedium)
                ChoiceRow(listOf(10, 20, 30), s.sessionSize, { "$it" }) { scope.launch { repo.setSessionSize(it) } }
            }
            Section("🔊 Voz") {
                Text("Velocidad: ${"%.1f".format(rate)}×", style = MaterialTheme.typography.bodyMedium)
                Slider(
                    value = rate,
                    onValueChange = { rate = it },
                    onValueChangeFinished = { scope.launch { repo.setTtsRate(rate) } },
                    valueRange = 0.5f..1.5f,
                    steps = 9,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { container.speaker.speak("Hello! Nice to meet you.", rate) }) { Text("Probar voz") }
                }
                SwitchRow("Leer la palabra automáticamente en las tarjetas", s.autoSpeak) { scope.launch { repo.setAutoSpeak(it) } }
                if (ttsStatus != Speaker.Status.READY) {
                    Text(
                        when (ttsStatus) {
                            Speaker.Status.LOADING -> "Cargando el motor de voz…"
                            Speaker.Status.MISSING_VOICE -> "Falta la voz en inglés en tu dispositivo."
                            else -> "Tu dispositivo no tiene un motor de síntesis de voz."
                        },
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                TextButton(onClick = {
                    try {
                        context.startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(context, "Busca «Texto a voz» en los ajustes de tu móvil", Toast.LENGTH_LONG).show()
                    }
                }) { Text("Descargar voces (sin conexión)") }
            }
            Section("🌙 Apariencia") {
                ChoiceRow(ThemeMode.entries, s.theme, { it.label }) { scope.launch { repo.setTheme(it) } }
            }
            Section("⏰ Recordatorio diario") {
                SwitchRow("Recordarme estudiar cada día", s.remindersOn) { on ->
                    if (on) {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            enableReminders(s.reminderHour, s.reminderMinute)
                        }
                    } else {
                        scope.launch { repo.setReminders(false, s.reminderHour, s.reminderMinute) }
                        ReminderScheduler.cancel(context)
                    }
                }
                if (s.remindersOn) {
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, h, m -> enableReminders(h, m) }, s.reminderHour, s.reminderMinute, true).show()
                    }) { Text("Hora: %02d:%02d · Cambiar".format(s.reminderHour, s.reminderMinute)) }
                    Text(
                        "Solo te avisaremos si ese día aún no has cumplido tu objetivo.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            Section("🗂️ Datos") {
                Text(
                    "Todo se guarda solo en este móvil. Sin cuentas, sin anuncios y sin conexión.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "Haz una copia en CSV (incluye tu progreso) para guardarla en Drive, pasarla a otro móvil o editarla en Excel.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { csv.export(null, backupFileName()) }, enabled = !csv.busy, modifier = Modifier.weight(1f)) {
                        Text("Exportar CSV")
                    }
                    OutlinedButton(onClick = csv.import, enabled = !csv.busy, modifier = Modifier.weight(1f)) {
                        Text("Importar CSV")
                    }
                }
                TextButton(onClick = { confirmReset = true }) { Text("Reiniciar mi progreso", color = Bad) }
            }
            Text(
                "VocaPDF 1.0",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(8.dp),
            )
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("¿Reiniciar el progreso?") },
            text = { Text("Se conservarán tus listas y palabras, pero se borrarán estadísticas, racha, XP y el estado de repaso de cada palabra.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    scope.launch {
                        container.repository.resetProgress()
                        repo.resetGameRecords()
                        Toast.makeText(context, "Progreso reiniciado", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Reiniciar", color = Bad) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            HorizontalDivider()
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
