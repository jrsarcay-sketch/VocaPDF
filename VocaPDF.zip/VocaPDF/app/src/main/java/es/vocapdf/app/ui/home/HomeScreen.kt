package es.vocapdf.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import es.vocapdf.app.appContainer
import es.vocapdf.app.domain.Gamification
import es.vocapdf.app.ui.components.BigButton
import es.vocapdf.app.ui.theme.Coral
import es.vocapdf.app.ui.theme.Teal
import java.time.LocalTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onStudy: () -> Unit, onChallenge: () -> Unit, onDecks: () -> Unit, onSettings: () -> Unit) {
    val repo = appContainer().repository
    val overviewFlow = remember { repo.overview() }
    val ov by overviewFlow.collectAsStateWithLifecycle(initialValue = null)
    val tip = remember { Gamification.tips.random() }
    val greeting = remember {
        when (LocalTime.now().hour) {
            in 6..13 -> "¡Buenos días!"
            in 14..20 -> "¡Buenas tardes!"
            else -> "¡Buenas noches!"
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("VocaPDF") },
                actions = { IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, contentDescription = "Ajustes") } },
            )
        },
    ) { padding ->
        val o = ov
        if (o == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(greeting, style = MaterialTheme.typography.headlineMedium)

            // Racha + nivel
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🔥", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (o.streak == 1) "1 día de racha" else "${o.streak} días de racha",
                                style = MaterialTheme.typography.titleLarge,
                            )
                            Text(
                                if (o.today.reviewed > 0) "¡Hoy ya has estudiado!" else "Estudia hoy para mantenerla",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row {
                        Text("Nivel ${o.level.level} · ${o.level.name}", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("${o.totalXp} XP", style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { o.level.progress },
                        modifier = Modifier.fillMaxWidth().height(10.dp),
                        strokeCap = StrokeCap.Round,
                    )
                    Text(
                        "${o.level.xpForNext - o.level.xpInLevel} XP para el siguiente nivel",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }

            // Objetivo diario
            val goal = o.settings.dailyGoal
            val done = o.today.reviewed.coerceAtMost(goal)
            Card {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            progress = { done.toFloat() / goal },
                            modifier = Modifier.size(72.dp),
                            strokeWidth = 8.dp,
                            color = Teal,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                            strokeCap = StrokeCap.Round,
                        )
                        Text("$done/$goal", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("Objetivo de hoy", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (o.today.goalReached) "¡Conseguido! 🎉 Sigue si te apetece." else "Repasa $goal palabras para cumplirlo.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }

            if (o.totalWords == 0) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Empieza importando tu vocabulario", style = MaterialTheme.typography.titleMedium)
                        Text("Elige un PDF con palabras en inglés y su traducción, o escríbelas a mano.")
                        BigButton("Importar mi primer PDF", onDecks, icon = Icons.Filled.PictureAsPdf, color = Coral)
                    }
                }
            } else {
                BigButton(
                    if (o.due > 0) "Repasar ahora · ${o.due} pendientes" else "Practicar ahora",
                    onStudy,
                    icon = Icons.Filled.PlayArrow,
                )
                BigButton(
                    "Reto diario",
                    onChallenge,
                    icon = Icons.Filled.Bolt,
                    color = Coral,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MiniStat("${o.totalWords}", "palabras", Modifier.weight(1f))
                    MiniStat("${o.learned}", "aprendidas", Modifier.weight(1f))
                    MiniStat("${o.accuracy} %", "aciertos", Modifier.weight(1f))
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                Row(Modifier.padding(16.dp)) {
                    Text("💡", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.width(10.dp))
                    Text(tip, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
private fun MiniStat(value: String, label: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleLarge)
            Text(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}
