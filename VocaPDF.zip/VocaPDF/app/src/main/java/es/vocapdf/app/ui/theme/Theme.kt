package es.vocapdf.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Paleta propia: violeta, coral y turquesa
val Violet = Color(0xFF5B4BE0)
val Coral = Color(0xFFFF7A59)
val Teal = Color(0xFF14B8A6)
val Sun = Color(0xFFFFB020)
val Good = Color(0xFF22A06B)
val Bad = Color(0xFFE5484D)

private val LightColors = lightColorScheme(
    primary = Violet,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE6E1FF),
    onPrimaryContainer = Color(0xFF1C1366),
    secondary = Coral,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE1D8),
    onSecondaryContainer = Color(0xFF5A1A08),
    tertiary = Teal,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFCDF5EF),
    onTertiaryContainer = Color(0xFF033D36),
    background = Color(0xFFF7F5FF),
    onBackground = Color(0xFF1A1830),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1A1830),
    surfaceVariant = Color(0xFFEDEAF7),
    onSurfaceVariant = Color(0xFF55526B),
    surfaceContainer = Color(0xFFF1EEFB),
    surfaceContainerHigh = Color(0xFFEAE6F8),
    error = Bad,
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB4AAFF),
    onPrimary = Color(0xFF221873),
    primaryContainer = Color(0xFF3D30B0),
    onPrimaryContainer = Color(0xFFE6E1FF),
    secondary = Color(0xFFFFA68D),
    onSecondary = Color(0xFF5A1A08),
    secondaryContainer = Color(0xFF7A2E17),
    onSecondaryContainer = Color(0xFFFFE1D8),
    tertiary = Color(0xFF5EE0CE),
    onTertiary = Color(0xFF033D36),
    tertiaryContainer = Color(0xFF0B5C52),
    onTertiaryContainer = Color(0xFFCDF5EF),
    background = Color(0xFF12111C),
    onBackground = Color(0xFFE7E4F5),
    surface = Color(0xFF1B1A28),
    onSurface = Color(0xFFE7E4F5),
    surfaceVariant = Color(0xFF2A2839),
    onSurfaceVariant = Color(0xFFC6C2DA),
    surfaceContainer = Color(0xFF211F30),
    surfaceContainerHigh = Color(0xFF2A2839),
    error = Color(0xFFFF8A8E),
)

private val AppTypography = Typography().run {
    copy(
        headlineMedium = headlineMedium.copy(fontWeight = FontWeight.Bold),
        headlineSmall = headlineSmall.copy(fontWeight = FontWeight.Bold),
        titleLarge = titleLarge.copy(fontWeight = FontWeight.Bold),
        titleMedium = titleMedium.copy(fontWeight = FontWeight.SemiBold),
        bodyLarge = TextStyle(fontSize = 17.sp, lineHeight = 24.sp),
    )
}

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
)

@Composable
fun VocaTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content,
    )
}
