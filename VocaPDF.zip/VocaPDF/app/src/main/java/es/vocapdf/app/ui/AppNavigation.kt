package es.vocapdf.app.ui

import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import es.vocapdf.app.appContainer
import es.vocapdf.app.ui.decks.DeckDetailScreen
import es.vocapdf.app.ui.decks.DecksScreen
import es.vocapdf.app.ui.games.GameMode
import es.vocapdf.app.ui.games.GameScreen
import es.vocapdf.app.ui.games.GamesScreen
import es.vocapdf.app.ui.home.HomeScreen
import es.vocapdf.app.ui.importer.ImportScreen
import es.vocapdf.app.ui.progress.ProgressScreen
import es.vocapdf.app.ui.settings.SettingsScreen
import es.vocapdf.app.ui.study.StudyScreen

object Routes {
    const val HOME = "home"
    const val DECKS = "decks"
    const val STUDY = "study"
    const val PLAY = "play"
    const val PROGRESS = "progress"
    const val SETTINGS = "settings"
    const val DECK = "deck/{id}"
    const val IMPORT = "import/{mode}"
    const val GAME = "game/{mode}?deck={deck}"
    const val STUDY_DECK = "studydeck/{deck}"

    fun deck(id: Long) = "deck/$id"
    fun import(fromPdf: Boolean) = "import/${if (fromPdf) "pdf" else "paste"}"
    fun game(mode: GameMode, deckId: Long?) = "game/${mode.name}?deck=${deckId ?: -1}"
    fun studyDeck(deckId: Long) = "studydeck/$deckId"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab(Routes.HOME, "Inicio", Icons.Filled.Home),
    Tab(Routes.DECKS, "Mis listas", Icons.Filled.CollectionsBookmark),
    Tab(Routes.STUDY, "Estudiar", Icons.Filled.Style),
    Tab(Routes.PLAY, "Jugar", Icons.Filled.SportsEsports),
    Tab(Routes.PROGRESS, "Progreso", Icons.Filled.EmojiEvents),
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AppNavigation() {
    val nav = rememberNavController()
    val container = appContainer()
    val pending by container.pendingImport.collectAsStateWithLifecycle()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route

    // PDF recibido desde "Abrir con…" / "Compartir"
    val graphReady = backStack != null
    LaunchedEffect(pending, graphReady) {
        if (pending != null && graphReady && route?.startsWith("import") != true) nav.navigate(Routes.import(true))
    }

    Scaffold(
        bottomBar = {
            if (tabs.any { it.route == route }) {
                NavigationBar {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = { nav.navigateTab(tab.route) },
                            icon = { Icon(tab.icon, contentDescription = null) },
                            label = { Text(tab.label, maxLines = 1) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        val bottom = PaddingValues(bottom = padding.calculateBottomPadding())
        NavHost(
            nav,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(bottom).consumeWindowInsets(bottom),
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    onStudy = { nav.navigateTab(Routes.STUDY) },
                    onChallenge = { nav.navigate(Routes.game(GameMode.DAILY, null)) },
                    onDecks = { nav.navigateTab(Routes.DECKS) },
                    onSettings = { nav.navigate(Routes.SETTINGS) },
                )
            }
            composable(Routes.DECKS) {
                DecksScreen(
                    onOpenDeck = { nav.navigate(Routes.deck(it)) },
                    onImport = { fromPdf -> nav.navigate(Routes.import(fromPdf)) },
                )
            }
            composable(Routes.DECK, arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                val id = entry.arguments?.getLong("id") ?: return@composable
                DeckDetailScreen(
                    deckId = id,
                    onBack = { nav.popBackStack() },
                    onStudy = { nav.navigate(Routes.studyDeck(id)) },
                    onPlay = { nav.navigate(Routes.game(GameMode.CHOICE, id)) },
                )
            }
            composable(Routes.IMPORT, arguments = listOf(navArgument("mode") { type = NavType.StringType })) { entry ->
                ImportScreen(
                    fromPdf = entry.arguments?.getString("mode") == "pdf",
                    onBack = { nav.popBackStack() },
                    onSaved = { deckId ->
                        nav.popBackStack()
                        nav.navigate(Routes.deck(deckId))
                    },
                )
            }
            composable(Routes.STUDY) { StudyScreen(initialDeckId = null, onBack = null) }
            composable(Routes.STUDY_DECK, arguments = listOf(navArgument("deck") { type = NavType.LongType })) { entry ->
                StudyScreen(initialDeckId = entry.arguments?.getLong("deck"), onBack = { nav.popBackStack() })
            }
            composable(Routes.PLAY) {
                GamesScreen(onPlay = { mode, deckId -> nav.navigate(Routes.game(mode, deckId)) })
            }
            composable(
                Routes.GAME,
                arguments = listOf(
                    navArgument("mode") { type = NavType.StringType },
                    navArgument("deck") { type = NavType.LongType; defaultValue = -1L },
                ),
            ) { entry ->
                val mode = runCatching { GameMode.valueOf(entry.arguments?.getString("mode") ?: "") }.getOrDefault(GameMode.CHOICE)
                val deck = entry.arguments?.getLong("deck")?.takeIf { it >= 0 }
                GameScreen(mode = mode, deckId = deck, onExit = { nav.popBackStack() })
            }
            composable(Routes.PROGRESS) { ProgressScreen() }
            composable(Routes.SETTINGS) { SettingsScreen(onBack = { nav.popBackStack() }) }
        }
    }
}

private fun NavHostController.navigateTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
