package es.vocapdf.app.ui.study

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import es.vocapdf.app.appContainer
import es.vocapdf.app.audio.Speaker
import es.vocapdf.app.audio.rememberSpeechRecognizer
import es.vocapdf.app.data.db.Word
import es.vocapdf.app.domain.Grade
import es.vocapdf.app.ui.components.BigButton
import es.vocapdf.app.ui.components.DeckSelector
import es.vocapdf.app.ui.components.EmptyState
import es.vocapdf.app.ui.theme.Bad
import es.vocapdf.app.ui.theme.Good
import es.vocapdf.app.ui.theme.Sun

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyScreen(initialDeckId: Long?, onBack: (() -> Unit)?) {
    val container = appContainer()
    val vm: StudyViewModel = viewModel(factory = viewModelFactory { initializer { StudyViewModel(container) } })
    LaunchedEffect(Unit) { vm.initOnce(initialDeckId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (vm.phase == StudyViewModel.Phase.CARDS) "Tarjeta ${vm.position} de ${vm.sessionTotal}" else "Estudiar") },
                navigationIcon = {
                    when {
                        vm.phase == StudyViewModel.Phase.CARDS ->
                            IconButton(onClick = { vm.quit() }) { Icon(Icons.Filled.Close, "Terminar sesión") }
                        onBack != null ->
                            IconButton(onClick = onBack) { Icon(Icons.Filled.Close, "Volver") }
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (vm.phase) {
                StudyViewModel.Phase.SETUP -> StudySetup(vm)
                StudyViewModel.Phase.LOADING -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                StudyViewModel.Phase.EMPTY -> EmptyState(
                    "🎉",
                    "¡Todo al día!",
                    if (vm.isExtraPractice) "Esta lista no tiene palabras todavía." else "No tienes palabras pendientes de repaso. Puedes hacer un repaso extra con las más difíciles.",
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (!vm.isExtraPractice) BigButton("Repaso extra", { vm.start(extra = true) }, icon = Icons.Filled.PlayArrow)
                        OutlinedButton(onClick = { vm.backToSetup() }, modifier = Modifier.fillMaxWidth()) { Text("Elegir otra lista") }
                    }
                }
                StudyViewModel.Phase.CARDS -> vm.current?.let { CardSession(vm, it) }
                StudyViewModel.Phase.DONE -> ResultPanel(
                    emoji = if (vm.accuracy >= 70) "🏆" else "🌟",
                    title = "¡Sesión completada!",
                    message = vm.message,
                    stats = listOf(
                        "${vm.reviewed}" to "repasos",
                        "${vm.accuracy} %" to "aciertos",
                        "+${vm.xpGained}" to "XP",
                    ),
                    extra = if (vm.goalReachedNow) "🎯 ¡Objetivo diario cumplido! +50 XP de bonus" else null,
                    primary = "Seguir estudiando" to { vm.start() },
                    secondary = "Terminar" to { if (onBack != null) onBack() else vm.backToSetup() },
                )
            }
        }
    }
}

@Composable
private fun StudySetup(vm: StudyViewModel) {
    val container = appContainer()
    val decksFlow = remember { container.repository.allDecks() }
    val decks by decksFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    val ovFlow = remember { container.repository.overview() }
    val ov by ovFlow.collectAsStateWithLifecycle(initialValue = null)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Repaso con tarjetas", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Toca la tarjeta para darle la vuelta y di con sinceridad si te la sabías. " +
                "Las palabras que fallas vuelven antes; las que sabes, cada vez más tarde.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        DeckSelector(decks, vm.deckId, { vm.deckId = it })
        ov?.let { o ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text("🔔 ${o.due} palabras pendientes en total", style = MaterialTheme.typography.titleMedium)
                    Text("Sesiones de ${o.settings.sessionSize} tarjetas (cámbialo en Ajustes)", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        if (decks.isEmpty()) {
            Text("Primero crea o importa una lista en «Mis listas».", color = MaterialTheme.colorScheme.secondary)
        } else {
            BigButton("Empezar repaso", { vm.start() }, icon = Icons.Filled.PlayArrow)
        }
    }
}

@Composable
private fun CardSession(vm: StudyViewModel, word: Word) {
    val container = appContainer()
    val ttsStatus by container.speaker.status.collectAsStateWithLifecycle()
    val recognize = rememberSpeechRecognizer { vm.onSpeechResult(it) }
    val rotation by animateFloatAsState(if (vm.flipped) 180f else 0f, tween(400), label = "flip")
    val density = LocalDensity.current

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        LinearProgressIndicator(
            progress = { (vm.position - 1).toFloat() / vm.sessionTotal.coerceAtLeast(1) },
            modifier = Modifier.fillMaxWidth().height(8.dp),
            strokeCap = StrokeCap.Round,
        )

        // Tarjeta que gira
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 260.dp)
                .graphicsLayer {
                    rotationY = rotation
                    cameraDistance = 12f * density.density
                }
                .clickable { vm.flipped = !vm.flipped },
            colors = CardDefaults.cardColors(
                containerColor = if (rotation <= 90f) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.tertiaryContainer,
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        ) {
            Box(
                Modifier.fillMaxWidth().heightIn(min = 260.dp).padding(24.dp).graphicsLayer { if (rotation > 90f) rotationY = 180f },
                contentAlignment = Alignment.Center,
            ) {
                if (rotation <= 90f) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🇬🇧 Inglés", style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(10.dp))
                        Text(word.english, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                        word.pronunciation?.let {
                            Text("/$it/", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("Toca para ver la traducción", style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🇪🇸 Español", style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(10.dp))
                        Text(word.spanish, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(8.dp))
                        Text(word.english, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        word.topic?.let { Text("Tema: $it", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }

        // Audio y pronunciación
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            FilledTonalIconButton(onClick = { vm.speak() }, enabled = ttsStatus == Speaker.Status.READY, modifier = Modifier.width(64.dp).height(56.dp)) {
                Icon(Icons.AutoMirrored.Filled.VolumeUp, "Escuchar")
            }
            FilledTonalIconButton(onClick = { vm.speakSlow() }, enabled = ttsStatus == Speaker.Status.READY, modifier = Modifier.width(64.dp).height(56.dp)) {
                Icon(Icons.Filled.SlowMotionVideo, "Escuchar despacio")
            }
            if (recognize != null) {
                FilledTonalIconButton(onClick = recognize, modifier = Modifier.width(64.dp).height(56.dp)) {
                    Icon(Icons.Filled.Mic, "Practicar pronunciación")
                }
            }
        }
        if (ttsStatus == Speaker.Status.MISSING_VOICE) {
            Text("Falta la voz en inglés: instálala en Ajustes ▸ Voz.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
        vm.feedback?.let { f ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(14.dp).fillMaxWidth()) {
                    Text("${f.emoji} ${f.message}", style = MaterialTheme.typography.titleMedium)
                    if (f.heard.isNotBlank()) Text("He entendido: «${f.heard}»", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        if (!vm.flipped) {
            BigButton("Ver traducción", { vm.flipped = true })
        } else {
            Text("¿Te la sabías?", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                GradeButton("Necesito\nrepasarla", "😅", Bad, Modifier.weight(1f)) { vm.grade(Grade.AGAIN) }
                GradeButton("Casi", "🤔", Sun, Modifier.weight(1f)) { vm.grade(Grade.ALMOST) }
                GradeButton("La sé", "😎", Good, Modifier.weight(1f)) { vm.grade(Grade.KNOW) }
            }
        }
    }
}

@Composable
private fun GradeButton(label: String, emoji: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 76.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White),
        shape = MaterialTheme.shapes.medium,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, style = MaterialTheme.typography.titleLarge)
            Text(label, textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
        }
    }
}

/** Panel de resultados reutilizado por el estudio y los juegos. */
@Composable
fun ResultPanel(
    emoji: String,
    title: String,
    message: String,
    stats: List<Pair<String, String>>,
    extra: String?,
    primary: Pair<String, () -> Unit>,
    secondary: Pair<String, () -> Unit>,
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(emoji, style = MaterialTheme.typography.displayLarge)
        Text(title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Text(message, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            stats.forEach { (v, l) ->
                Card(Modifier.weight(1f)) {
                    Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(v, style = MaterialTheme.typography.titleLarge)
                        Text(l, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        extra?.let {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                Text(it, Modifier.padding(14.dp), style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
            }
        }
        BigButton(primary.first, primary.second)
        OutlinedButton(onClick = secondary.second, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text(secondary.first) }
    }
}
