package es.vocapdf.app.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

/** Síntesis de voz en inglés usando el motor TTS del dispositivo (funciona sin conexión si la voz está descargada). */
class Speaker(context: Context) : TextToSpeech.OnInitListener {

    enum class Status { LOADING, READY, MISSING_VOICE, UNAVAILABLE }

    private val _status = MutableStateFlow(Status.LOADING)
    val status: StateFlow<Status> = _status

    private val tts = TextToSpeech(context.applicationContext, this)

    @Volatile var rate: Float = 0.9f

    override fun onInit(result: Int) {
        if (result != TextToSpeech.SUCCESS) {
            _status.value = Status.UNAVAILABLE
            return
        }
        val ok = listOf(Locale.US, Locale.UK, Locale.ENGLISH).any { loc ->
            val r = tts.setLanguage(loc)
            r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        }
        _status.value = if (ok) Status.READY else Status.MISSING_VOICE
    }

    /** Lee el texto en inglés. Devuelve false si la voz no está disponible. */
    fun speak(text: String, speed: Float = rate): Boolean {
        if (_status.value != Status.READY || text.isBlank()) return false
        tts.setSpeechRate(speed)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "voca-${System.nanoTime()}")
        return true
    }

    fun stop() {
        runCatching { tts.stop() }
    }
}
