package es.vocapdf.app.pdf

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import kotlin.math.max

class PdfException(message: String) : Exception(message)

/** Extrae el texto de un PDF con PDFBox, manteniendo las columnas de las tablas separadas por "\t". */
class PdfTextExtractor(private val context: Context) {

    @Volatile private var initialized = false

    suspend fun extract(uri: Uri): String = withContext(Dispatchers.IO) {
        if (!initialized) {
            PDFBoxResourceLoader.init(context.applicationContext)
            initialized = true
        }
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: throw PdfException("No se ha podido abrir el archivo.")
            input.use { stream ->
                PDDocument.load(stream).use { doc ->
                    val stripper = ColumnAwareStripper().apply { sortByPosition = true }
                    stripper.getText(doc)
                }
            }
        } catch (e: InvalidPasswordException) {
            throw PdfException("El PDF está protegido con contraseña.")
        } catch (e: PdfException) {
            throw e
        } catch (e: IOException) {
            throw PdfException("No se ha podido leer el PDF (${e.message ?: "formato no válido"}).")
        } catch (e: OutOfMemoryError) {
            throw PdfException("El PDF es demasiado grande para este dispositivo.")
        }
    }

    fun displayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()
}

/**
 * PDFTextStripper escribe las palabras de una línea separadas por espacios. Aquí detectamos
 * los huecos horizontales grandes (típicos entre columnas de una tabla) y escribimos un
 * tabulador para que el analizador pueda separar las columnas.
 */
private class ColumnAwareStripper : PDFTextStripper() {
    private var lastEndX = -1f

    override fun writeString(text: String?, textPositions: MutableList<TextPosition>?) {
        if (!textPositions.isNullOrEmpty()) {
            val first = textPositions.first()
            val avgWidth = textPositions.map { it.widthDirAdj }.average().toFloat().coerceAtLeast(1f)
            if (lastEndX >= 0f && first.xDirAdj - lastEndX > max(avgWidth * 2.5f, 12f)) {
                output.write("\t")
            }
            val last = textPositions.last()
            lastEndX = last.xDirAdj + last.widthDirAdj
        }
        super.writeString(text, textPositions)
    }

    override fun writeLineSeparator() {
        lastEndX = -1f
        super.writeLineSeparator()
    }
}
