package es.vocapdf.app.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Cómo de bien se sabía la palabra. */
enum class Grade { KNOW, ALMOST, AGAIN }

/** Estado de repetición espaciada de una palabra (independiente de la base de datos). */
data class SrsState(
    val box: Int = 0,
    val dueAt: Long = 0L,
    val reviews: Int = 0,
    val correct: Int = 0,
    val lapses: Int = 0,
    val lastReviewedAt: Long? = null,
    /** 0 = nueva, 1 = fácil, 2 = casi, 3 = difícil */
    val difficulty: Int = 0,
)

/**
 * Sistema Leitner con 8 cajas.
 *  - "La sé": sube una caja y se repasa dentro de 1, 2, 4, 8, 16, 32 o 64 días.
 *  - "Casi": se queda en su caja (mínimo la 1) y vuelve a la mitad de tiempo.
 *  - "Necesito repasarla": vuelve a la caja 0 y se repite en pocos minutos.
 * Una palabra se considera "aprendida" a partir de la caja [LEARNED_BOX].
 */
object Srs {
    val intervalDays = intArrayOf(0, 1, 2, 4, 8, 16, 32, 64)
    val MAX_BOX = intervalDays.lastIndex
    const val LEARNED_BOX = 3
    private const val AGAIN_DELAY_MS = 5L * 60 * 1000

    fun schedule(s: SrsState, grade: Grade, now: Long, zone: ZoneId = ZoneId.systemDefault()): SrsState {
        val base = s.copy(reviews = s.reviews + 1, lastReviewedAt = now)
        return when (grade) {
            Grade.KNOW -> {
                val box = (s.box + 1).coerceAtMost(MAX_BOX)
                base.copy(box = box, dueAt = startOfDayPlus(now, intervalDays[box], zone), correct = s.correct + 1, difficulty = 1)
            }
            Grade.ALMOST -> {
                val box = s.box.coerceAtLeast(1)
                val days = (intervalDays[box] / 2).coerceAtLeast(1)
                base.copy(box = box, dueAt = startOfDayPlus(now, days, zone), correct = s.correct + 1, difficulty = 2)
            }
            Grade.AGAIN -> base.copy(box = 0, dueAt = now + AGAIN_DELAY_MS, lapses = s.lapses + 1, difficulty = 3)
        }
    }

    /** Error en un juego: baja una caja y la palabra queda pendiente para hoy. */
    fun penalize(s: SrsState, now: Long): SrsState =
        s.copy(box = (s.box - 1).coerceAtLeast(0), dueAt = now, lapses = s.lapses + 1, difficulty = 3, lastReviewedAt = now)

    private fun startOfDayPlus(now: Long, days: Int, zone: ZoneId): Long {
        val day = Instant.ofEpochMilli(now).atZone(zone).toLocalDate().plusDays(days.toLong())
        return day.atStartOfDay(zone).toInstant().toEpochMilli()
    }

    fun dayKey(millis: Long = System.currentTimeMillis(), zone: ZoneId = ZoneId.systemDefault()): String =
        Instant.ofEpochMilli(millis).atZone(zone).toLocalDate().toString()

    fun today(zone: ZoneId = ZoneId.systemDefault()): LocalDate = LocalDate.now(zone)
}
