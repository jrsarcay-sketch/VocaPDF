package es.vocapdf.app.ui.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import es.vocapdf.app.appContainer
import es.vocapdf.app.data.Overview
import es.vocapdf.app.domain.Medal
import es.vocapdf.app.ui.components.StatTile
import java.time.format.TextStyle
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen() {
    val repo = appContainer().repository
    val flow = remember { repo.overview() }
    val ov by flow.collectAsStateWithLifecycle(initialValue = null)

    Scaffold(topBar = { TopAppBar(title = { Text("Mi progreso") }) }) { padding ->
        val o = ov
        if (o == null) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Nivel ${o.level.level} · ${o.level.name} · ${o.totalXp} XP", style = MaterialTheme.typography.titleMedium)

            val c = MaterialTheme.colorScheme
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("${o.learned}", "palabras aprendidas", "🌳", Modifier.weight(1f), c.tertiaryContainer)
                StatTile("${o.due}", "pendientes de repaso", "🔔", Modifier.weight(1f), c.secondaryContainer)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("${o.streak}", "días de racha (mejor: ${o.bestStreak})", "🔥", Modifier.weight(1f), c.primaryContainer)
                StatTile("${o.accuracy} %", "precisión (${o.answered} respuestas)", "🎯", Modifier.weight(1f), c.surfaceContainerHigh)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(formatTime(o.secondsStudied), "tiempo estudiado", "⏳", Modifier.weight(1f), c.surfaceContainerHigh)
                StatTile("${o.totalWords}", "palabras en ${o.decks} listas", "📚", Modifier.weight(1f), c.primaryContainer)
            }

            WeekChart(o)

            Text("Medallas (${o.medals.count { it.unlocked }}/${o.medals.size})", style = MaterialTheme.typography.titleMedium)
            o.medals.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { MedalCard(it, Modifier.weight(1f)) }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun WeekChart(o: Overview) {
    val max = (o.last7.maxOf { it.second }).coerceAtLeast(o.settings.dailyGoal).coerceAtLeast(1)
    val barColor = MaterialTheme.colorScheme.primary
    val goalColor = MaterialTheme.colorScheme.secondary
    val track = MaterialTheme.colorScheme.surfaceVariant
    Card {
        Column(Modifier.padding(16.dp)) {
            Text("Últimos 7 días", style = MaterialTheme.typography.titleMedium)
            Text("Palabras repasadas por día · línea = tu objetivo", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(12.dp))
            Canvas(Modifier.fillMaxWidth().height(140.dp)) {
                val n = o.last7.size
                val slot = size.width / n
                val barW = slot * 0.55f
                o.last7.forEachIndexed { i, (_, v) ->
                    val x = i * slot + (slot - barW) / 2
                    drawRoundRect(track, Offset(x, 0f), Size(barW, size.height), CornerRadius(10f, 10f))
                    val h = size.height * v / max
                    if (h > 0) drawRoundRect(barColor, Offset(x, size.height - h), Size(barW, h), CornerRadius(10f, 10f))
                }
                val gy = size.height - size.height * o.settings.dailyGoal / max
                drawLine(goalColor, Offset(0f, gy), Offset(size.width, gy), strokeWidth = 4f)
            }
            Row(Modifier.fillMaxWidth()) {
                o.last7.forEach { (d, v) ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$v", style = MaterialTheme.typography.labelMedium)
                        Text(
                            d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("es", "ES")).take(3),
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MedalCard(m: Medal, modifier: Modifier) {
    Card(
        modifier.heightIn(min = 120.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (m.unlocked) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Column(
            Modifier.padding(10.dp).fillMaxWidth().alpha(if (m.unlocked) 1f else 0.45f),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(if (m.unlocked) m.emoji else "🔒", style = MaterialTheme.typography.headlineMedium)
            Text(m.title, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center)
            Text(m.description, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
        }
    }
}

private fun formatTime(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    return when {
        h > 0 -> "${h} h ${m} min"
        m > 0 -> "$m min"
        else -> "$seconds s"
    }
}
