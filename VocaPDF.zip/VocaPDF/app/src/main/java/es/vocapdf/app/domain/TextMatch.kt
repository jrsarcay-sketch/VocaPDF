package es.vocapdf.app.domain

import java.text.Normalizer

enum class MatchResult { EXACT, CLOSE, WRONG }

/** Comparación flexible de respuestas: sin tildes, sin mayúsculas, tolera erratas pequeñas. */
object TextMatch {

    private val diacritics = Regex("""\p{Mn}+""")
    private val punctuation = Regex("""[¿?¡!.,;:"“”«»()\[\]{}…]""")
    private val spaces = Regex("""\s+""")
    private val leadingArticles = Regex("""^(?:to|the|a|an|el|la|los|las|un|una|unos|unas)\s+""")

    fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(diacritics, "")
            .replace('’', '\'')
            .replace(punctuation, " ")
            .replace(spaces, " ")
            .trim()

    /** Quita artículos iniciales y el "to" de los infinitivos para comparar el núcleo. */
    private fun core(s: String): String = normalize(s.replace(Regex("""\([^)]*\)"""), " ")).replace(leadingArticles, "").trim()

    /** Alternativas aceptadas: "big / large", "grande, amplio" ... */
    fun alternatives(expected: String): List<String> {
        val parts = expected.split('/', ',', ';', '|').map { it.trim() }.filter { it.isNotEmpty() }
        return (parts + expected).distinct()
    }

    fun check(input: String, expected: String): MatchResult {
        val given = core(input)
        if (given.isEmpty()) return MatchResult.WRONG
        var best = MatchResult.WRONG
        for (alt in alternatives(expected)) {
            val target = core(alt)
            if (target.isEmpty()) continue
            if (given == target || given.replace(" ", "") == target.replace(" ", "")) return MatchResult.EXACT
            val dist = levenshtein(given, target)
            val tolerance = when {
                target.length >= 9 -> 2
                target.length >= 5 -> 1
                else -> 0
            }
            if (dist <= tolerance) best = MatchResult.CLOSE
        }
        return best
    }

    /** Similitud 0..1 entre dos textos (para la práctica de pronunciación). */
    fun similarity(a: String, b: String): Double {
        val x = normalize(a)
        val y = normalize(b)
        if (x.isEmpty() && y.isEmpty()) return 1.0
        val maxLen = maxOf(x.length, y.length)
        return 1.0 - levenshtein(x, y).toDouble() / maxLen
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }
}
