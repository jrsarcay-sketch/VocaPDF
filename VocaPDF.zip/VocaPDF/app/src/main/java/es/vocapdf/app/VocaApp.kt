package es.vocapdf.app

import android.app.Application
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import es.vocapdf.app.audio.Speaker
import es.vocapdf.app.data.SettingsRepository
import es.vocapdf.app.data.VocabRepository
import es.vocapdf.app.data.db.AppDatabase
import es.vocapdf.app.pdf.PdfTextExtractor
import es.vocapdf.app.reminders.ReminderScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import android.net.Uri

class VocaApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        ReminderScheduler.createChannel(this)
    }
}

/** Dependencias compartidas de la app (localizador de servicios sencillo). */
class AppContainer(app: Application) {
    val database = AppDatabase.build(app)
    val settings = SettingsRepository(app)
    val repository = VocabRepository(database, settings)
    val speaker = Speaker(app)
    val pdfExtractor = PdfTextExtractor(app)
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    /** PDF pendiente de importar (desde el selector o desde "Abrir con…"). */
    val pendingImport = MutableStateFlow<Uri?>(null)

    init {
        scope.launch { settings.settings.collect { speaker.rate = it.ttsRate } }
    }
}

@Composable
fun appContainer(): AppContainer = (LocalContext.current.applicationContext as VocaApp).container
