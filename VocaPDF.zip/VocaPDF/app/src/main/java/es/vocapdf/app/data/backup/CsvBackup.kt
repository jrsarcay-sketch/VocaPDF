package es.vocapdf.app.data.backup

import es.vocapdf.app.domain.SrsState
import es.vocapdf.app.domain.TextMatch
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

/** Una fila de la copia de seguridad: palabra + lista + (opcionalmente) su progreso. */
data class BackupRow(
    val deck: String?,
    val english: String,
    val spanish: String,
    val pronunciation: String? = null,
    val topic: String? = null,
    val srs: SrsState? = null,
)

data class CsvParseResult(val rows: List<BackupRow>, val skippedLines: Int, val hasDeckColumn: Boolean)

/**
 * Formato CSV de VocaPDF, pensado para abrirse bien en Excel / Google Sheets en español:
 *  - Separador ";" y codificación UTF-8 con BOM.
 *  - Columnas: lista;ingles;espanol;pronunciacion;tema;caja;proximo_repaso;repasos;aciertos;fallos;dificultad
 *
 * Al importar se acepta también cualquier CSV sencillo (separado por ";", "," o tabulador) con
 * columnas Inglés/Español; si no hay encabezado, la 1.ª columna es inglés y la 2.ª español.
 */
object CsvBackup {

    const val BOM = "﻿"
    private const val SEP = ';'

    private val header = listOf(
        "lista", "ingles", "espanol", "pronunciacion", "tema",
        "caja", "proximo_repaso", "repasos", "aciertos", "fallos", "dificultad",
    )

    private enum class Col { DECK, EN, ES, PRON, TOPIC, BOX, DUE, REVIEWS, CORRECT, LAPSES, DIFFICULTY }

    private val aliases: Map<Col, Set<String>> = mapOf(
        Col.DECK to setOf("lista", "mazo", "deck", "list"),
        Col.EN to setOf("ingles", "english", "palabra", "word"),
        Col.ES to setOf("espanol", "spanish", "castellano", "traduccion", "translation", "significado"),
        Col.PRON to setOf("pronunciacion", "pronunciation", "fonetica", "ipa"),
        Col.TOPIC to setOf("tema", "topic", "categoria", "category"),
        Col.BOX to setOf("caja", "box"),
        Col.DUE to setOf("proximo repaso", "proximo_repaso", "due"),
        Col.REVIEWS to setOf("repasos", "reviews"),
        Col.CORRECT to setOf("aciertos", "correct"),
        Col.LAPSES to setOf("fallos", "lapses"),
        Col.DIFFICULTY to setOf("dificultad", "difficulty"),
    )

    // ------------------------------------------------------------------ exportar

    fun write(rows: List<BackupRow>, zone: ZoneId = ZoneId.systemDefault()): String = buildString {
        append(BOM)
        appendLine(header.joinToString(SEP.toString()))
        for (r in rows) {
            val s = r.srs
            val fields = listOf(
                r.deck.orEmpty(), r.english, r.spanish, r.pronunciation.orEmpty(), r.topic.orEmpty(),
                s?.box?.toString().orEmpty(),
                s?.dueAt?.takeIf { it > 0 }?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), zone).withNano(0).toString() }.orEmpty(),
                s?.reviews?.toString().orEmpty(),
                s?.correct?.toString().orEmpty(),
                s?.lapses?.toString().orEmpty(),
                s?.difficulty?.toString().orEmpty(),
            )
            appendLine(fields.joinToString(SEP.toString()) { escape(it) })
        }
    }

    private fun escape(v: String): String =
        if (v.any { it == SEP || it == '"' || it == '\n' || it == '\r' || it == ',' }) "\"" + v.replace("\"", "\"\"") + "\"" else v

    // ------------------------------------------------------------------ importar

    fun parse(text: String, zone: ZoneId = ZoneId.systemDefault()): CsvParseResult {
        val clean = text.removePrefix(BOM)
        val firstLine = clean.lineSequence().firstOrNull { it.isNotBlank() } ?: return CsvParseResult(emptyList(), 0, false)
        val sep = detectSeparator(firstLine)
        val records = splitRecords(clean, sep).filter { rec -> rec.any { it.isNotBlank() } }
        if (records.isEmpty()) return CsvParseResult(emptyList(), 0, false)

        val headerMap = mapHeader(records.first())
        val cols = headerMap ?: mapOf(Col.EN to 0, Col.ES to 1)
        val data = if (headerMap != null) records.drop(1) else records

        var skipped = 0
        val rows = data.mapNotNull { rec ->
            fun get(c: Col) = cols[c]?.let { rec.getOrNull(it) }?.trim().orEmpty()
            val en = get(Col.EN)
            val es = get(Col.ES)
            if (en.isEmpty() || es.isEmpty()) { skipped++; return@mapNotNull null }
            val hasProgress = Col.BOX in cols && get(Col.BOX).isNotEmpty()
            val srs = if (hasProgress) SrsState(
                box = get(Col.BOX).toIntOrNull()?.coerceIn(0, 7) ?: 0,
                dueAt = parseDate(get(Col.DUE), zone),
                reviews = get(Col.REVIEWS).toIntOrNull() ?: 0,
                correct = get(Col.CORRECT).toIntOrNull() ?: 0,
                lapses = get(Col.LAPSES).toIntOrNull() ?: 0,
                difficulty = get(Col.DIFFICULTY).toIntOrNull()?.coerceIn(0, 3) ?: 0,
            ) else null
            BackupRow(
                deck = get(Col.DECK).ifEmpty { null },
                english = en,
                spanish = es,
                pronunciation = get(Col.PRON).trim('/', '[', ']', ' ').ifEmpty { null },
                topic = get(Col.TOPIC).ifEmpty { null },
                srs = srs,
            )
        }
        return CsvParseResult(rows, skipped, Col.DECK in cols)
    }

    private fun parseDate(s: String, zone: ZoneId): Long {
        if (s.isBlank()) return 0L
        return runCatching { LocalDateTime.parse(s).atZone(zone).toInstant().toEpochMilli() }
            .recoverCatching { java.time.LocalDate.parse(s).atStartOfDay(zone).toInstant().toEpochMilli() }
            .getOrDefault(0L)
    }

    private fun detectSeparator(line: String): Char {
        val candidates = listOf(';', '\t', ',')
        return candidates.maxBy { c -> line.count { it == c } }.takeIf { c -> line.count { it == c } > 0 } ?: SEP
    }

    private fun mapHeader(cells: List<String>): Map<Col, Int>? {
        val map = mutableMapOf<Col, Int>()
        cells.forEachIndexed { i, raw ->
            val n = TextMatch.normalize(raw.replace('_', ' '))
            val col = aliases.entries.firstOrNull { (_, names) -> names.any { TextMatch.normalize(it.replace('_', ' ')) == n } }?.key
            if (col != null && col !in map) map[col] = i
        }
        return if (Col.EN in map && Col.ES in map) map else null
    }

    /** Divide el texto en registros respetando comillas (RFC 4180). */
    internal fun splitRecords(text: String, sep: Char): List<List<String>> {
        val out = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') { field.append('"'); i++ } else inQuotes = false
                } else field.append(c)
            } else when (c) {
                '"' -> inQuotes = true
                sep -> { row.add(field.toString()); field.clear() }
                '\r' -> {}
                '\n' -> { row.add(field.toString()); field.clear(); out.add(row); row = mutableListOf() }
                else -> field.append(c)
            }
            i++
        }
        if (field.isNotEmpty() || row.isNotEmpty()) { row.add(field.toString()); out.add(row) }
        return out
    }
}
