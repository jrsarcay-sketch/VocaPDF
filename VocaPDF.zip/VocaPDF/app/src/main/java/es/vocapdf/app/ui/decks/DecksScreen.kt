package es.vocapdf.app.ui.decks

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import es.vocapdf.app.appContainer
import es.vocapdf.app.data.db.DeckSummary
import es.vocapdf.app.ui.components.EmptyState
import es.vocapdf.app.ui.components.rememberCsvActions
import es.vocapdf.app.ui.theme.Coral

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DecksScreen(onOpenDeck: (Long) -> Unit, onImport: (fromPdf: Boolean) -> Unit) {
    val container = appContainer()
    val flow = remember { container.repository.deckSummaries() }
    val decks by flow.collectAsStateWithLifecycle(initialValue = null)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            container.pendingImport.value = uri
            onImport(true)
        }
    }
    val pickPdf = { picker.launch(arrayOf("application/pdf")) }
    val csv = rememberCsvActions()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Mis listas") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = pickPdf,
                icon = { Icon(Icons.Filled.PictureAsPdf, null) },
                text = { Text("Importar PDF") },
                containerColor = Coral,
                contentColor = MaterialTheme.colorScheme.onSecondary,
            )
        },
    ) { padding ->
        val list = decks ?: return@Scaffold
        if (list.isEmpty()) {
            EmptyState(
                "📄",
                "Aún no tienes listas",
                "Importa un PDF con vocabulario inglés–español o pega tus palabras.",
                Modifier.padding(padding),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onImport(false) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.ContentPaste, null)
                        Text("  Pegar o escribir palabras")
                    }
                    OutlinedButton(onClick = csv.import, enabled = !csv.busy, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.TableChart, null)
                        Text("  Importar CSV")
                    }
                }
            }
            return@Scaffold
        }
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onImport(false) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.ContentPaste, null)
                        Text("  Pegar palabras")
                    }
                    OutlinedButton(onClick = csv.import, enabled = !csv.busy, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.TableChart, null)
                        Text("  Importar CSV")
                    }
                }
            }
            items(list, key = { it.id }) { d -> DeckCard(d) { onOpenDeck(d.id) } }
        }
    }
}

@Composable
private fun DeckCard(d: DeckSummary, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(16.dp)) {
            Text(d.name, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${d.total} palabras · ${d.learned} aprendidas",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f),
                )
                if (d.due > 0) Text("🔔 ${d.due} por repasar", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { if (d.total == 0) 0f else d.learned.toFloat() / d.total },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                strokeCap = StrokeCap.Round,
            )
        }
    }
}
