package es.vocapdf.app.ui.decks

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import es.vocapdf.app.appContainer
import es.vocapdf.app.data.db.Word
import es.vocapdf.app.domain.Srs
import es.vocapdf.app.ui.components.BackTopBar
import es.vocapdf.app.ui.components.BigButton
import es.vocapdf.app.ui.components.Dot
import es.vocapdf.app.ui.components.EmptyState
import es.vocapdf.app.ui.components.rememberCsvActions
import es.vocapdf.app.ui.theme.Bad
import es.vocapdf.app.ui.theme.Coral
import es.vocapdf.app.ui.theme.Good
import es.vocapdf.app.ui.theme.Sun
import kotlinx.coroutines.launch

@Composable
fun DeckDetailScreen(deckId: Long, onBack: () -> Unit, onStudy: () -> Unit, onPlay: () -> Unit) {
    val container = appContainer()
    val repo = container.repository
    val scope = rememberCoroutineScope()
    val deckFlow = remember(deckId) { repo.deck(deckId) }
    val wordsFlow = remember(deckId) { repo.wordsOfDeck(deckId) }
    val deck by deckFlow.collectAsStateWithLifecycle(initialValue = null)
    val words by wordsFlow.collectAsStateWithLifecycle(initialValue = emptyList())

    var editing by remember { mutableStateOf<Word?>(null) }
    var adding by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val csv = rememberCsvActions()

    Scaffold(
        topBar = {
            BackTopBar(deck?.name ?: "", onBack) {
                IconButton(onClick = { csv.export(deckId, deck?.name ?: "lista") }, enabled = words.isNotEmpty() && !csv.busy) {
                    Icon(Icons.Filled.FileDownload, "Exportar a CSV")
                }
                IconButton(onClick = { renaming = true }) { Icon(Icons.Filled.Edit, "Renombrar lista") }
                IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Borrar lista") }
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, "Añadir palabra") }
        },
    ) { padding ->
        if (words.isEmpty()) {
            EmptyState("✏️", "Lista vacía", "Pulsa + para añadir palabras.", Modifier.padding(padding))
        } else {
            LazyColumn(
                Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        BigButton("Estudiar", onStudy, Modifier.weight(1f), icon = Icons.Filled.PlayArrow)
                        BigButton("Jugar", onPlay, Modifier.weight(1f), icon = Icons.Filled.SportsEsports, color = Coral)
                    }
                    Text(
                        "${words.size} palabras · toca una para editarla",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 10.dp),
                    )
                }
                items(words, key = { it.id }) { w ->
                    Card(Modifier.fillMaxWidth().clickable { editing = w }) {
                        Row(Modifier.padding(start = 14.dp, end = 4.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Dot(
                                when {
                                    w.reviews == 0 -> MaterialTheme.colorScheme.outline
                                    w.box >= Srs.LEARNED_BOX -> Good
                                    w.difficulty == 3 -> Bad
                                    else -> Sun
                                },
                            )
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(w.english, style = MaterialTheme.typography.titleMedium)
                                Text(w.spanish, style = MaterialTheme.typography.bodyMedium)
                                val extra = listOfNotNull(w.pronunciation?.let { "/$it/" }, w.topic).joinToString(" · ")
                                if (extra.isNotEmpty()) Text(extra, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { container.speaker.speak(w.english) }) {
                                Icon(Icons.AutoMirrored.Filled.VolumeUp, "Escuchar")
                            }
                        }
                    }
                }
            }
        }
    }

    if (adding || editing != null) {
        val w = editing
        WordDialog(
            initial = w,
            onDismiss = { adding = false; editing = null },
            onDelete = w?.let { { scope.launch { repo.deleteWord(it) }; editing = null } },
            onSave = { en, es, pron, topic ->
                scope.launch {
                    if (w == null) repo.addWord(deckId, en, es, pron, topic)
                    else repo.updateWord(w.copy(english = en.trim(), spanish = es.trim(), pronunciation = pron.trim().ifBlank { null }, topic = topic.trim().ifBlank { null }))
                }
                adding = false; editing = null
            },
        )
    }

    if (renaming) {
        var name by remember { mutableStateOf(deck?.name ?: "") }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Renombrar lista") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Nombre") }) },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(), onClick = { scope.launch { repo.renameDeck(deckId, name) }; renaming = false }) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("Cancelar") } },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Borrar la lista?") },
            text = { Text("Se borrarán sus ${words.size} palabras y su progreso. No se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    scope.launch { repo.deleteDeck(deckId); onBack() }
                }) { Text("Borrar", color = Bad) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } },
        )
    }
}

@Composable
fun WordDialog(
    initial: Word?,
    onDismiss: () -> Unit,
    onDelete: (() -> Unit)?,
    onSave: (en: String, es: String, pron: String, topic: String) -> Unit,
) {
    var en by remember { mutableStateOf(initial?.english ?: "") }
    var es by remember { mutableStateOf(initial?.spanish ?: "") }
    var pron by remember { mutableStateOf(initial?.pronunciation ?: "") }
    var topic by remember { mutableStateOf(initial?.topic ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nueva palabra" else "Editar palabra") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(en, { en = it }, label = { Text("Inglés") }, singleLine = true)
                OutlinedTextField(es, { es = it }, label = { Text("Español") }, singleLine = true)
                OutlinedTextField(pron, { pron = it }, label = { Text("Pronunciación (opcional)") }, singleLine = true)
                OutlinedTextField(topic, { topic = it }, label = { Text("Tema (opcional)") }, singleLine = true)
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text("Borrar palabra", color = Bad) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = en.isNotBlank() && es.isNotBlank(), onClick = { onSave(en, es, pron, topic) }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
