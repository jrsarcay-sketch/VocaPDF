package es.vocapdf.app.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

enum class ThemeMode(val label: String) { SYSTEM("Sistema"), LIGHT("Claro"), DARK("Oscuro") }

data class Settings(
    val dailyGoal: Int = 10,
    val sessionSize: Int = 20,
    val ttsRate: Float = 0.9f,
    val autoSpeak: Boolean = true,
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val remindersOn: Boolean = false,
    val reminderHour: Int = 19,
    val reminderMinute: Int = 0,
    val perfectGames: Int = 0,
    val bestTimed: Int = 0,
)

class SettingsRepository(private val context: Context) {

    private object K {
        val goal = intPreferencesKey("daily_goal")
        val session = intPreferencesKey("session_size")
        val rate = floatPreferencesKey("tts_rate")
        val autoSpeak = booleanPreferencesKey("auto_speak")
        val theme = stringPreferencesKey("theme")
        val remindersOn = booleanPreferencesKey("reminders_on")
        val remHour = intPreferencesKey("reminder_hour")
        val remMinute = intPreferencesKey("reminder_minute")
        val perfect = intPreferencesKey("perfect_games")
        val bestTimed = intPreferencesKey("best_timed")
    }

    val settings: Flow<Settings> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { p -> p.toSettings() }

    suspend fun current(): Settings = settings.first()

    private fun Preferences.toSettings() = Settings(
        dailyGoal = this[K.goal] ?: 10,
        sessionSize = this[K.session] ?: 20,
        ttsRate = this[K.rate] ?: 0.9f,
        autoSpeak = this[K.autoSpeak] ?: true,
        theme = this[K.theme]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM,
        remindersOn = this[K.remindersOn] ?: false,
        reminderHour = this[K.remHour] ?: 19,
        reminderMinute = this[K.remMinute] ?: 0,
        perfectGames = this[K.perfect] ?: 0,
        bestTimed = this[K.bestTimed] ?: 0,
    )

    suspend fun setDailyGoal(v: Int) = context.dataStore.edit { it[K.goal] = v }
    suspend fun setSessionSize(v: Int) = context.dataStore.edit { it[K.session] = v }
    suspend fun setTtsRate(v: Float) = context.dataStore.edit { it[K.rate] = v }
    suspend fun setAutoSpeak(v: Boolean) = context.dataStore.edit { it[K.autoSpeak] = v }
    suspend fun setTheme(v: ThemeMode) = context.dataStore.edit { it[K.theme] = v.name }
    suspend fun setReminders(on: Boolean, hour: Int, minute: Int) = context.dataStore.edit {
        it[K.remindersOn] = on; it[K.remHour] = hour; it[K.remMinute] = minute
    }
    suspend fun addPerfectGame() = context.dataStore.edit { it[K.perfect] = (it[K.perfect] ?: 0) + 1 }

    /** Devuelve true si es un nuevo récord. */
    suspend fun submitTimedScore(score: Int): Boolean {
        var record = false
        context.dataStore.edit {
            if (score > (it[K.bestTimed] ?: 0)) { it[K.bestTimed] = score; record = true }
        }
        return record
    }

    suspend fun resetGameRecords() = context.dataStore.edit { it.remove(K.perfect); it.remove(K.bestTimed) }
}
