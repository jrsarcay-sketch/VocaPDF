package es.vocapdf.app.data.db

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.Upsert
import es.vocapdf.app.domain.SrsState
import kotlinx.coroutines.flow.Flow

// ---------------------------------------------------------------------------- Tablas

/** Lista o "mazo" de vocabulario (p. ej. "Viajes"). */
@Entity(tableName = "decks")
data class Deck(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    /** Nombre del PDF de origen, si lo hay. */
    val source: String? = null,
)

/** Palabra o frase con su estado de repetición espaciada (progreso). */
@Entity(
    tableName = "words",
    foreignKeys = [ForeignKey(entity = Deck::class, parentColumns = ["id"], childColumns = ["deckId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("deckId"), Index("dueAt")],
)
data class Word(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deckId: Long,
    val english: String,
    val spanish: String,
    val pronunciation: String? = null,
    val topic: String? = null,
    // --- progreso (sistema Leitner) ---
    val box: Int = 0,
    val dueAt: Long = 0,
    val reviews: Int = 0,
    val correct: Int = 0,
    val lapses: Int = 0,
    val lastReviewedAt: Long? = null,
    /** 0 nueva · 1 fácil · 2 casi · 3 difícil */
    val difficulty: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
) {
    val srs: SrsState get() = SrsState(box, dueAt, reviews, correct, lapses, lastReviewedAt, difficulty)
    fun withSrs(s: SrsState) = copy(
        box = s.box, dueAt = s.dueAt, reviews = s.reviews, correct = s.correct,
        lapses = s.lapses, lastReviewedAt = s.lastReviewedAt, difficulty = s.difficulty,
    )
}

/** Historial de repeticiones: cada respuesta del usuario. */
@Entity(
    tableName = "review_log",
    foreignKeys = [ForeignKey(entity = Word::class, parentColumns = ["id"], childColumns = ["wordId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("wordId"), Index("day")],
)
data class ReviewLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wordId: Long,
    /** yyyy-MM-dd */
    val day: String,
    val timestamp: Long,
    val mode: String,
    val correct: Boolean,
)

/** Estadísticas agregadas por día. */
@Entity(tableName = "daily_stats")
data class DailyStat(
    @PrimaryKey val day: String,
    val reviewed: Int = 0,
    val correct: Int = 0,
    val secondsStudied: Long = 0,
    val xp: Int = 0,
    val goalReached: Boolean = false,
    /** Mejor puntuación del reto diario de ese día (null = no jugado). */
    val challengeScore: Int? = null,
)

// ---------------------------------------------------------------------------- Vistas

data class DeckSummary(
    val id: Long,
    val name: String,
    val createdAt: Long,
    val total: Int,
    val learned: Int,
    val due: Int,
)

data class WordCounts(
    val total: Int,
    val learned: Int,
    val due: Int,
    val decks: Int,
)

// ---------------------------------------------------------------------------- DAOs

@Dao
interface DeckDao {
    @Query(
        """
        SELECT d.id AS id, d.name AS name, d.createdAt AS createdAt,
               COUNT(w.id) AS total,
               COALESCE(SUM(CASE WHEN w.box >= 3 THEN 1 ELSE 0 END), 0) AS learned,
               COALESCE(SUM(CASE WHEN w.id IS NOT NULL AND w.dueAt <= :now THEN 1 ELSE 0 END), 0) AS due
        FROM decks d LEFT JOIN words w ON w.deckId = d.id
        GROUP BY d.id ORDER BY d.createdAt DESC
        """,
    )
    fun observeSummaries(now: Long): Flow<List<DeckSummary>>

    @Query("SELECT * FROM decks ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<Deck>>

    @Query("SELECT * FROM decks WHERE id = :id")
    fun observe(id: Long): Flow<Deck?>

    @Query("SELECT * FROM decks")
    suspend fun all(): List<Deck>

    @Insert
    suspend fun insert(deck: Deck): Long

    @Query("UPDATE decks SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)

    @Query("DELETE FROM decks WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface WordDao {
    @Insert
    suspend fun insertAll(words: List<Word>)

    @Insert
    suspend fun insert(word: Word): Long

    @Update
    suspend fun update(word: Word)

    @Delete
    suspend fun delete(word: Word)

    @Query("SELECT * FROM words WHERE id = :id")
    suspend fun get(id: Long): Word?

    @Query("SELECT * FROM words WHERE deckId = :deckId ORDER BY english COLLATE NOCASE")
    fun observeByDeck(deckId: Long): Flow<List<Word>>

    @Query("SELECT * FROM words WHERE (:deckId IS NULL OR deckId = :deckId) ORDER BY deckId, english COLLATE NOCASE")
    suspend fun allWords(deckId: Long?): List<Word>

    /** Palabras pendientes: primero las de cajas bajas y más atrasadas. */
    @Query(
        """SELECT * FROM words WHERE (:deckId IS NULL OR deckId = :deckId) AND dueAt <= :now
           ORDER BY box ASC, lapses DESC, dueAt ASC LIMIT :limit""",
    )
    suspend fun due(deckId: Long?, now: Long, limit: Int): List<Word>

    /** Repaso extra cuando no hay pendientes: las más débiles. */
    @Query("SELECT * FROM words WHERE (:deckId IS NULL OR deckId = :deckId) ORDER BY box ASC, dueAt ASC LIMIT :limit")
    suspend fun weakest(deckId: Long?, limit: Int): List<Word>

    /** Para juegos: aleatorio pero sesgado hacia las palabras más flojas. */
    @Query("SELECT * FROM words WHERE (:deckId IS NULL OR deckId = :deckId) ORDER BY box + (ABS(RANDOM()) % 4) ASC LIMIT :limit")
    suspend fun forGames(deckId: Long?, limit: Int): List<Word>

    @Query("SELECT * FROM words WHERE (:deckId IS NULL OR deckId = :deckId) ORDER BY RANDOM() LIMIT :limit")
    suspend fun random(deckId: Long?, limit: Int): List<Word>

    @Query("SELECT COUNT(*) FROM words WHERE (:deckId IS NULL OR deckId = :deckId)")
    suspend fun count(deckId: Long?): Int

    @Query("SELECT COUNT(*) FROM words WHERE dueAt <= :now")
    suspend fun dueCount(now: Long): Int

    @Query(
        """SELECT (SELECT COUNT(*) FROM words) AS total,
                  (SELECT COUNT(*) FROM words WHERE box >= 3) AS learned,
                  (SELECT COUNT(*) FROM words WHERE dueAt <= :now) AS due,
                  (SELECT COUNT(*) FROM decks) AS decks""",
    )
    fun observeCounts(now: Long): Flow<WordCounts>

    @Query("UPDATE words SET box = 0, dueAt = 0, reviews = 0, correct = 0, lapses = 0, lastReviewedAt = NULL, difficulty = 0")
    suspend fun resetProgress()
}

@Dao
interface StatsDao {
    @Query("SELECT * FROM daily_stats WHERE day = :day")
    suspend fun get(day: String): DailyStat?

    @Upsert
    suspend fun upsert(stat: DailyStat)

    @Query("SELECT * FROM daily_stats ORDER BY day DESC")
    fun observeAll(): Flow<List<DailyStat>>

    @Insert
    suspend fun log(entry: ReviewLog)

    @Query("DELETE FROM daily_stats")
    suspend fun clearStats()

    @Query("DELETE FROM review_log")
    suspend fun clearLog()
}

// ---------------------------------------------------------------------------- Base de datos

@Database(entities = [Deck::class, Word::class, ReviewLog::class, DailyStat::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun deckDao(): DeckDao
    abstract fun wordDao(): WordDao
    abstract fun statsDao(): StatsDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "vocapdf.db").build()
    }
}
