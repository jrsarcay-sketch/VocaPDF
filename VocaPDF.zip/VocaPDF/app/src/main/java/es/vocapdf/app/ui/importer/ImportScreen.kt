package es.vocapdf.app.ui.importer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import es.vocapdf.app.appContainer
import es.vocapdf.app.ui.components.BackTopBar
import es.vocapdf.app.ui.components.BigButton

@Composable
fun ImportScreen(fromPdf: Boolean, onBack: () -> Unit, onSaved: (Long) -> Unit) {
    val container = appContainer()
    val vm: ImportViewModel = viewModel(factory = viewModelFactory { initializer { ImportViewModel(container) } })
    val pending by container.pendingImport.collectAsStateWithLifecycle()
    val decksFlow = remember { container.repository.allDecks() }
    val decks by decksFlow.collectAsStateWithLifecycle(initialValue = emptyList())

    LaunchedEffect(pending) {
        pending?.let {
            container.pendingImport.value = null
            vm.loadPdf(it)
        }
    }

    Scaffold(
        topBar = { BackTopBar(if (fromPdf) "Importar PDF" else "Pegar palabras", onBack) },
        bottomBar = {
            if (vm.reviewing) {
                Surface(tonalElevation = 3.dp) {
                    Column(Modifier.navigationBarsPadding().imePadding().padding(16.dp)) {
                        BigButton(
                            if (vm.saving) "Guardando…" else "Guardar ${vm.validCount} palabras",
                            onClick = { vm.save(onSaved) },
                            enabled = !vm.saving && vm.validCount > 0,
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when {
                vm.loading -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(16.dp))
                    Text("Leyendo el PDF…")
                }
                vm.reviewing -> ReviewList(vm, decks.map { it.id to it.name })
                else -> PasteOrError(vm, fromPdf)
            }
        }
    }
}

@Composable
private fun PasteOrError(vm: ImportViewModel, fromPdf: Boolean) {
    Column(
        Modifier.fillMaxSize().imePadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        vm.error?.let { ErrorCard(it) }
        if (fromPdf && vm.error == null) {
            Text("Esperando el PDF…", style = MaterialTheme.typography.bodyLarge)
        }
        Text(
            "Escribe o pega una palabra por línea, por ejemplo:\n" +
                "house - casa\nto run = correr\nGood morning: Buenos días",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
            value = vm.pasteText,
            onValueChange = { vm.pasteText = it },
            modifier = Modifier.fillMaxWidth().weight(1f).heightIn(min = 160.dp),
            label = { Text("Tus palabras") },
        )
        BigButton("Revisar palabras", onClick = { vm.parsePasted() })
    }
}

@Composable
private fun ErrorCard(msg: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Text(msg, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
    }
}

@Composable
private fun ReviewList(vm: ImportViewModel, decks: List<Pair<Long, String>>) {
    LazyColumn(
        Modifier.fillMaxSize().imePadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                vm.error?.let { ErrorCard(it) }
                vm.info?.let {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                        Text("✅ $it", Modifier.padding(14.dp))
                    }
                }
                TargetDeckPicker(vm, decks)
                if (vm.targetDeckId == null) {
                    OutlinedTextField(
                        value = vm.deckName,
                        onValueChange = { vm.deckName = it },
                        label = { Text("Nombre de la lista (p. ej. Viajes)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.addEmpty() }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Add, null); Text(" Añadir")
                    }
                    OutlinedButton(onClick = { vm.swapAll() }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.SwapHoriz, null); Text(" Invertir")
                    }
                }
                if (vm.source == null) {
                    TextButton(onClick = { vm.backToPaste() }) { Text("← Volver a editar el texto") }
                }
            }
        }
        items(vm.rows, key = { it.id }) { row -> RowEditor(row, vm::update) { vm.remove(row.id) } }
        if (vm.rows.isEmpty()) {
            item { Text("No hay palabras todavía.", Modifier.fillMaxWidth().padding(24.dp), textAlign = TextAlign.Center) }
        }
        if (vm.unmatched.isNotEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Líneas sin emparejar (${vm.unmatched.size})", style = MaterialTheme.typography.titleMedium)
                        Text(vm.unmatched.take(8).joinToString("\n"), style = MaterialTheme.typography.bodySmall)
                        if (vm.unmatched.size > 8) Text("…", style = MaterialTheme.typography.bodySmall)
                        Row {
                            TextButton(onClick = { vm.pairUnmatched() }) { Text("Emparejar líneas alternas") }
                            TextButton(onClick = { vm.discardUnmatched() }) { Text("Descartar") }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun TargetDeckPicker(vm: ImportViewModel, decks: List<Pair<Long, String>>) {
    if (decks.isEmpty()) return
    var open by remember { mutableStateOf(false) }
    val label = decks.firstOrNull { it.first == vm.targetDeckId }?.second?.let { "Añadir a: $it" } ?: "Crear una lista nueva"
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { Text(label) }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem(text = { Text("Crear una lista nueva") }, onClick = { vm.targetDeckId = null; open = false })
            decks.forEach { (id, name) ->
                DropdownMenuItem(text = { Text("Añadir a «$name»") }, onClick = { vm.targetDeckId = id; open = false })
            }
        }
    }
}

@Composable
private fun RowEditor(row: EditableRow, onChange: (EditableRow) -> Unit, onDelete: () -> Unit) {
    var expanded by remember { mutableStateOf(row.pronunciation.isNotEmpty() || row.topic.isNotEmpty()) }
    Card {
        Column(Modifier.padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        row.english, { onChange(row.copy(english = it)) },
                        label = { Text("Inglés") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        isError = row.english.isBlank(),
                    )
                    OutlinedTextField(
                        row.spanish, { onChange(row.copy(spanish = it)) },
                        label = { Text("Español") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        isError = row.spanish.isBlank(),
                    )
                    if (expanded) {
                        OutlinedTextField(
                            row.pronunciation, { onChange(row.copy(pronunciation = it)) },
                            label = { Text("Pronunciación") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        )
                        OutlinedTextField(
                            row.topic, { onChange(row.copy(topic = it)) },
                            label = { Text("Tema") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        )
                    } else {
                        TextButton(onClick = { expanded = true }) { Text("+ pronunciación / tema") }
                    }
                }
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Close, "Quitar") }
            }
        }
    }
}
