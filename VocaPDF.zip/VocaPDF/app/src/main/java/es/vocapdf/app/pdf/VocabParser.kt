package es.vocapdf.app.pdf

import es.vocapdf.app.domain.TextMatch

/** Una entrada de vocabulario detectada en el texto. */
data class ParsedEntry(
    val english: String,
    val spanish: String,
    val pronunciation: String? = null,
    val topic: String? = null,
)

data class ParseResult(
    val entries: List<ParsedEntry>,
    /** Líneas con texto que no se pudieron emparejar (el usuario puede revisarlas). */
    val unmatched: List<String>,
    /** true si se reconoció una fila de encabezado tipo "Inglés | Español | ...". */
    val detectedTable: Boolean,
    /** true si las columnas venían como español–inglés y se han invertido. */
    val swapped: Boolean,
)

/**
 * Convierte texto plano (extraído de un PDF o pegado por el usuario) en pares inglés–español.
 *
 * Formatos reconocidos, por línea:
 *  - Tablas: columnas separadas por tabulador (el extractor de PDF inserta "\t" en los huecos
 *    grandes entre columnas) o por "|". Si hay encabezado (Inglés, Español, Pronunciación, Tema)
 *    se usa para saber qué es cada columna.
 *  - Separadores: "=", "→", "->", " - ", " – ", " — ", ":", ";", "|".
 *  - Pronunciación entre /barras/ o [corchetes] junto a la palabra inglesa.
 *  - Encabezados de tema: una línea corta que termina en ":" (por ejemplo "Animales:").
 */
object VocabParser {

    private enum class Col { EN, ES, PRON, TOPIC }

    private val headerWords: Map<Col, Set<String>> = mapOf(
        Col.EN to setOf("ingles", "english", "en ingles", "palabra", "word", "inglés", "term", "termino"),
        Col.ES to setOf("espanol", "spanish", "castellano", "traduccion", "translation", "significado", "meaning", "en espanol"),
        Col.PRON to setOf("pronunciacion", "pronunciation", "fonetica", "ipa", "como se pronuncia", "se pronuncia", "sonido"),
        Col.TOPIC to setOf("tema", "topic", "categoria", "category", "unidad", "grupo", "tipo"),
    )

    private val bulletRegex = Regex("""^\s*(?:[-•*·▪●◦>]|\d{1,4}\s*[.)\-]|\(\d{1,4}\))\s*""")
    private val pageNumberRegex = Regex("""^\s*(?:p[aá]g(?:ina)?\.?\s*)?\d{1,4}\s*(?:/\s*\d{1,4})?\s*$""", RegexOption.IGNORE_CASE)
    private val pronInlineRegex = Regex("""\s*(/[^/]{1,40}/|\[[^\]]{1,40}])\s*""")
    private val ipaChars = Regex("[əʃʒθðŋæʊɪɔɑɜʌˈˌːɒɛʤʧ]")
    private val topicHeadingRegex = Regex("""^([^\t:=|]{2,40}):\s*$""")

    /** Separadores en orden de prioridad (el primero que funcione se usa). */
    private val separators = listOf(" = ", "=", " → ", "→", " -> ", "->", " – ", " — ", " - ", ":", ";", "|")

    fun parse(raw: String): ParseResult {
        val lines = normalize(raw)
        var columns: Map<Col, Int>? = null
        var currentTopic: String? = null
        val entries = mutableListOf<ParsedEntry>()
        val unmatched = mutableListOf<String>()

        for (line in lines) {
            // 1) ¿Encabezado de tabla?
            val headerMap = detectHeader(line)
            if (headerMap != null) {
                columns = headerMap
                continue
            }
            if (pageNumberRegex.matches(line)) continue

            val clean = line.replace(bulletRegex, "").trim()
            if (clean.isEmpty()) continue

            // 2) Fila de tabla con encabezado conocido
            val cells = splitCells(clean)
            if (columns != null && cells.size >= 2) {
                val e = fromColumns(cells, columns, currentTopic)
                if (e != null) { entries += e; continue }
            }

            // 3) Encabezado de tema ("Animales:")
            val heading = topicHeadingRegex.matchEntire(clean)
            if (heading != null && cells.size < 2) {
                currentTopic = heading.groupValues[1].trim()
                continue
            }

            // 4) Celdas sin encabezado o separadores
            val e = if (cells.size >= 2) fromCells(cells, currentTopic) else fromSeparators(clean, currentTopic)
            if (e != null) entries += e else unmatched += clean
        }

        val hasHeader = columns != null
        val (finalEntries, swapped) = if (hasHeader) entries to false else fixDirection(entries)
        return ParseResult(dedupe(finalEntries), unmatched, hasHeader, swapped)
    }

    /** Empareja líneas sueltas de dos en dos (inglés, español, inglés, español...). */
    fun pairAlternating(lines: List<String>): List<ParsedEntry> {
        val pairs = lines.chunked(2).filter { it.size == 2 }.mapNotNull { (a, b) -> buildEntry(a, b, null, null) }
        return fixDirection(pairs).first
    }

    // ---------------------------------------------------------------- helpers

    private fun normalize(raw: String): List<String> =
        raw.replace("\r\n", "\n").replace('\r', '\n')
            .replace(' ', ' ')
            .split('\n')
            .map { it.replace(Regex("""[ ]*\t[ \t]*"""), "\t").trim() }
            .filter { it.isNotBlank() }

    private fun splitCells(line: String): List<String> {
        val parts = when {
            '\t' in line -> line.split('\t')
            line.count { it == '|' } >= 1 && line.trim('|').contains('|') -> line.trim('|').split('|')
            else -> return listOf(line)
        }
        return parts.map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun detectHeader(line: String): Map<Col, Int>? {
        val cells = when {
            '\t' in line || '|' in line -> splitCells(line.replace(bulletRegex, ""))
            else -> line.split(Regex("""\s{2,}|\s*[;,/]\s*""")).map { it.trim() }.filter { it.isNotEmpty() }
        }
        if (cells.size < 2 || cells.size > 6) return null
        val map = mutableMapOf<Col, Int>()
        cells.forEachIndexed { i, cell ->
            val n = TextMatch.normalize(cell)
            val col = headerWords.entries.firstOrNull { (_, words) -> n in words.map(TextMatch::normalize) }?.key
                ?: return null // todas las celdas deben ser palabras de encabezado
            if (col !in map) map[col] = i
        }
        return if (Col.EN in map && Col.ES in map) map else null
    }

    private fun fromColumns(cells: List<String>, cols: Map<Col, Int>, topic: String?): ParsedEntry? {
        if (cells.size < cols.size) {
            // Alguna celda opcional (pronunciación o tema) está vacía: las columnas se han desplazado.
            val enFirst = cols.getValue(Col.EN) < cols.getValue(Col.ES)
            val en = if (enFirst) cells[0] else cells[1]
            val es = if (enFirst) cells[1] else cells[0]
            val extras = cells.drop(2)
            val pron = extras.firstOrNull { Col.PRON in cols && looksLikePronunciation(it) }
            val t = extras.firstOrNull { it != pron && Col.TOPIC in cols } ?: topic
            return buildEntry(en, es, pron, t)
        }
        val en = cells.getOrNull(cols.getValue(Col.EN)) ?: return null
        val es = cells.getOrNull(cols.getValue(Col.ES)) ?: return null
        val pron = cols[Col.PRON]?.let { cells.getOrNull(it) }
        val t = cols[Col.TOPIC]?.let { cells.getOrNull(it) } ?: topic
        return buildEntry(en, es, pron, t)
    }

    private fun fromCells(cells: List<String>, topic: String?): ParsedEntry? {
        val en = cells[0]
        val rest = cells.drop(1)
        val pron = rest.firstOrNull { looksLikePronunciation(it) }
        val others = rest.filter { it != pron }
        val es = others.firstOrNull() ?: return null
        val t = others.getOrNull(1) ?: topic
        return buildEntry(en, es, pron, t)
    }

    private fun fromSeparators(line: String, topic: String?): ParsedEntry? {
        for (sep in separators) {
            val idx = line.indexOf(sep)
            if (idx <= 0) continue
            val left = line.substring(0, idx)
            val right = line.substring(idx + sep.length)
            // Evitar partir palabras con guion ("T-shirt") cuando el separador es "-" sin espacios
            if (right.isBlank()) continue
            buildEntry(left, right, null, topic)?.let { return it }
        }
        return null
    }

    private fun looksLikePronunciation(s: String): Boolean {
        val t = s.trim()
        return (t.startsWith("/") && t.endsWith("/")) ||
            (t.startsWith("[") && t.endsWith("]")) ||
            ipaChars.containsMatchIn(t)
    }

    private fun buildEntry(enRaw: String, esRaw: String, pronRaw: String?, topic: String?): ParsedEntry? {
        var en = enRaw.trim()
        var pron = pronRaw?.trim()?.trim('/', '[', ']')?.trim()
        // Pronunciación pegada a la palabra: "house /haʊs/"
        pronInlineRegex.find(en)?.let { m ->
            if (pron.isNullOrBlank()) pron = m.groupValues[1].trim('/', '[', ']').trim()
            en = en.removeRange(m.range).trim()
        }
        var es = esRaw.trim()
        pronInlineRegex.find(es)?.let { m ->
            if (pron.isNullOrBlank()) pron = m.groupValues[1].trim('/', '[', ']').trim()
            es = es.removeRange(m.range).trim()
        }
        en = en.trim(' ', '-', '–', '—', ':', '=', ';', '|', '.', ',')
        es = es.trim(' ', '-', '–', '—', ':', '=', ';', '|', ',')
        if (es.endsWith('.') && !es.endsWith("..")) es = es.dropLast(1).trim()
        if (en.isEmpty() || es.isEmpty()) return null
        if (en.length > 140 || es.length > 140) return null
        if (en.none { it.isLetter() } || es.none { it.isLetter() }) return null
        return ParsedEntry(en, es, pron?.takeIf { it.isNotBlank() }, topic?.trim()?.takeIf { it.isNotBlank() })
    }

    /** Si la mayoría de pares parecen estar en orden español–inglés, los invierte. */
    internal fun fixDirection(entries: List<ParsedEntry>): Pair<List<ParsedEntry>, Boolean> {
        if (entries.isEmpty()) return entries to false
        var score = 0.0
        for (e in entries) {
            score += languageLean(e.english) - languageLean(e.spanish)
        }
        // score > 0 => la columna "english" suena a español
        val swap = score > 0.3 * entries.size
        return if (swap) entries.map { it.copy(english = it.spanish, spanish = it.english) } to true
        else entries to false
    }

    private val spanishWords = setOf(
        "el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "que", "y", "en", "por",
        "para", "es", "con", "mi", "tu", "su", "yo", "no", "se", "lo", "al", "muy", "esta", "estoy",
    )
    private val englishWords = setOf(
        "the", "a", "an", "to", "of", "is", "are", "you", "it", "with", "my", "your", "i", "and",
        "do", "does", "what", "how", "where", "please", "be", "have", "this", "that", "in", "on",
    )

    /** Positivo = parece español, negativo = parece inglés. */
    internal fun languageLean(text: String): Double {
        val lower = text.lowercase()
        var s = 0.0
        s += lower.count { it in "áéíóúñü¿¡" } * 1.5
        val tokens = lower.split(Regex("""[^\p{L}']+""")).filter { it.isNotEmpty() }
        for (t in tokens) {
            if (t in spanishWords) s += 1.0
            if (t in englishWords) s -= 1.0
            if (t.endsWith("ción") || t.endsWith("mente") || t.endsWith("dad")) s += 0.8
            if (t.contains("th") || t.contains("w") || t.contains("k") || t.endsWith("ing") || t.endsWith("'s")) s -= 0.6
            if (t.endsWith("o") || t.endsWith("a")) s += 0.15
        }
        return s
    }

    private fun dedupe(list: List<ParsedEntry>): List<ParsedEntry> {
        val seen = HashSet<String>()
        return list.filter { seen.add(TextMatch.normalize(it.english) + "|" + TextMatch.normalize(it.spanish)) }
    }
}
