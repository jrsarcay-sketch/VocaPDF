package es.vocapdf.app.domain

import java.time.LocalDate
import kotlin.math.sqrt

data class LevelInfo(val level: Int, val name: String, val xpInLevel: Int, val xpForNext: Int) {
    val progress: Float get() = if (xpForNext == 0) 1f else xpInLevel.toFloat() / xpForNext
}

data class Medal(val emoji: String, val title: String, val description: String, val unlocked: Boolean)

/** Datos globales que usan las medallas. */
data class MedalInput(
    val totalWords: Int,
    val learned: Int,
    val decks: Int,
    val streak: Int,
    val bestStreak: Int,
    val totalXp: Int,
    val answered: Int,
    val perfectGames: Int,
    val challengesDone: Int,
    val goalDays: Int,
)

object Gamification {
    const val GOAL_BONUS = 50

    fun xpFor(grade: Grade): Int = when (grade) {
        Grade.KNOW -> 10
        Grade.ALMOST -> 7
        Grade.AGAIN -> 2
    }

    fun xpForGame(correct: Boolean): Int = if (correct) 10 else 2

    private val levelNames = listOf(
        "Principiante", "Aprendiz", "Explorador", "Viajero", "Conversador",
        "Avanzado", "Experto", "Maestro", "Leyenda",
    )

    /** El nivel N empieza en 100·N·(N−1)/2 XP: 0, 100, 300, 600, 1000, 1500... */
    private fun xpAtLevel(level: Int) = 100 * level * (level - 1) / 2

    fun level(xp: Int): LevelInfo {
        val safe = xp.coerceAtLeast(0)
        var level = ((1 + sqrt(1 + 8.0 * safe / 100)) / 2).toInt().coerceAtLeast(1)
        while (xpAtLevel(level + 1) <= safe) level++
        while (level > 1 && xpAtLevel(level) > safe) level--
        val start = xpAtLevel(level)
        val next = xpAtLevel(level + 1)
        val name = levelNames.getOrElse(level - 1) { levelNames.last() }
        return LevelInfo(level, name, safe - start, next - start)
    }

    /** Racha actual: días seguidos con estudio que terminan hoy (o ayer, si hoy aún no has estudiado). */
    fun currentStreak(studyDays: Set<LocalDate>, today: LocalDate): Int {
        var day = if (today in studyDays) today else today.minusDays(1)
        var count = 0
        while (day in studyDays) { count++; day = day.minusDays(1) }
        return count
    }

    fun bestStreak(studyDays: Set<LocalDate>): Int {
        var best = 0
        for (d in studyDays) {
            if (d.minusDays(1) in studyDays) continue // no es el inicio de una racha
            var len = 0
            var cur = d
            while (cur in studyDays) { len++; cur = cur.plusDays(1) }
            best = maxOf(best, len)
        }
        return best
    }

    fun sessionMessage(reviewed: Int, accuracy: Int): String = when {
        reviewed == 0 -> "¡Vuelve cuando quieras!"
        accuracy >= 90 -> "¡Increíble! Has repasado $reviewed palabras con un $accuracy % de aciertos. 🏆"
        accuracy >= 70 -> "¡Muy bien! Has repasado $reviewed palabras hoy. 💪"
        accuracy >= 40 -> "¡Buen trabajo! $reviewed palabras repasadas. La práctica hace al maestro. 🌱"
        else -> "¡No te rindas! Cada repaso cuenta: $reviewed palabras practicadas. 🚀"
    }

    val tips = listOf(
        "Escucha cada palabra y repítela en voz alta: tu memoria lo agradecerá.",
        "Mejor 10 minutos cada día que una hora una vez a la semana.",
        "Si fallas una palabra, no pasa nada: volverá pronto para que la fijes.",
        "Intenta inventar una frase con cada palabra nueva.",
        "Los juegos rápidos son perfectos para los ratos muertos.",
        "Cuando una palabra llega a la caja 3, ya la consideramos aprendida.",
    )

    fun medals(m: MedalInput): List<Medal> = listOf(
        Medal("📄", "Primer mazo", "Importa o crea tu primera lista", m.decks >= 1),
        Medal("📚", "Coleccionista", "Ten 100 palabras en tus listas", m.totalWords >= 100),
        Medal("🌱", "Primeros pasos", "Aprende 10 palabras", m.learned >= 10),
        Medal("🌿", "Vocabulario creciente", "Aprende 50 palabras", m.learned >= 50),
        Medal("🌳", "Gran vocabulario", "Aprende 200 palabras", m.learned >= 200),
        Medal("🦉", "Sabio", "Aprende 500 palabras", m.learned >= 500),
        Medal("🔥", "En racha", "Estudia 3 días seguidos", m.bestStreak >= 3),
        Medal("⚡", "Semana perfecta", "Estudia 7 días seguidos", m.bestStreak >= 7),
        Medal("🏅", "Imparable", "Estudia 30 días seguidos", m.bestStreak >= 30),
        Medal("🎯", "Objetivo cumplido", "Cumple tu objetivo diario", m.goalDays >= 1),
        Medal("💯", "Partida perfecta", "Termina un juego sin fallos", m.perfectGames >= 1),
        Medal("🗓️", "Retador", "Completa 5 retos diarios", m.challengesDone >= 5),
        Medal("⭐", "Mil puntos", "Consigue 1.000 XP", m.totalXp >= 1000),
        Medal("👑", "Dedicación", "Responde 1.000 preguntas", m.answered >= 1000),
    )
}
