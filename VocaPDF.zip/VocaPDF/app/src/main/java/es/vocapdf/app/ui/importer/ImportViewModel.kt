package es.vocapdf.app.ui.importer

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import es.vocapdf.app.AppContainer
import es.vocapdf.app.pdf.ParsedEntry
import es.vocapdf.app.pdf.PdfException
import es.vocapdf.app.pdf.VocabParser
import kotlinx.coroutines.launch

/** Fila editable de la pantalla de revisión. */
data class EditableRow(
    val id: Long,
    val english: String,
    val spanish: String,
    val pronunciation: String = "",
    val topic: String = "",
)

class ImportViewModel(private val container: AppContainer) : ViewModel() {

    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var info by mutableStateOf<String?>(null); private set
    var deckName by mutableStateOf("")
    var targetDeckId by mutableStateOf<Long?>(null)
    var source: String? = null; private set
    var pasteText by mutableStateOf("")
    /** true cuando ya hay algo que revisar (tras leer el PDF o el texto). */
    var reviewing by mutableStateOf(false); private set
    var saving by mutableStateOf(false); private set

    val rows = mutableStateListOf<EditableRow>()
    val unmatched = mutableStateListOf<String>()
    private var nextId = 1L

    fun loadPdf(uri: Uri) {
        if (loading) return
        loading = true
        error = null
        viewModelScope.launch {
            try {
                val name = container.pdfExtractor.displayName(uri)
                source = name
                if (deckName.isBlank()) deckName = name?.substringBeforeLast('.')?.replace('_', ' ')?.trim().orEmpty()
                val text = container.pdfExtractor.extract(uri)
                if (text.isBlank()) {
                    error = "Este PDF no contiene texto seleccionable (puede ser una imagen escaneada). " +
                        "Copia el texto y usa la opción de pegar."
                } else {
                    applyParse(text)
                }
            } catch (e: PdfException) {
                error = e.message
            } catch (e: Exception) {
                error = "No se ha podido leer el PDF: ${e.localizedMessage ?: e.javaClass.simpleName}"
            } finally {
                loading = false
            }
        }
    }

    fun parsePasted() {
        error = null
        if (pasteText.isBlank()) { error = "Pega o escribe primero tus palabras."; return }
        applyParse(pasteText)
    }

    private fun applyParse(text: String) {
        val result = VocabParser.parse(text)
        rows.clear()
        rows.addAll(result.entries.map { it.toRow() })
        unmatched.clear()
        unmatched.addAll(result.unmatched)
        reviewing = true
        info = buildString {
            append("Se han detectado ${result.entries.size} pares")
            if (result.detectedTable) append(" en una tabla")
            append(".")
            if (result.swapped) append(" Las columnas venían en orden español–inglés y se han invertido.")
            if (result.unmatched.isNotEmpty()) append(" Hay ${result.unmatched.size} líneas sin emparejar al final.")
        }
        if (result.entries.isEmpty() && result.unmatched.isNotEmpty()) {
            info = "No se ha encontrado un formato claro. Si el texto alterna inglés y español en líneas " +
                "separadas, pulsa «Emparejar líneas alternas»."
        }
    }

    private fun ParsedEntry.toRow() = EditableRow(nextId++, english, spanish, pronunciation.orEmpty(), topic.orEmpty())

    fun update(row: EditableRow) {
        val i = rows.indexOfFirst { it.id == row.id }
        if (i >= 0) rows[i] = row
    }

    fun remove(id: Long) { rows.removeAll { it.id == id } }

    fun addEmpty() { rows.add(0, EditableRow(nextId++, "", "")) }

    fun swapAll() {
        val swapped = rows.map { it.copy(english = it.spanish, spanish = it.english) }
        rows.clear(); rows.addAll(swapped)
    }

    fun pairUnmatched() {
        val pairs = VocabParser.pairAlternating(unmatched.toList())
        rows.addAll(pairs.map { it.toRow() })
        unmatched.clear()
        info = "Se han añadido ${pairs.size} pares. Revísalos antes de guardar."
    }

    fun discardUnmatched() = unmatched.clear()

    fun backToPaste() { reviewing = false }

    val validCount: Int get() = rows.count { it.english.isNotBlank() && it.spanish.isNotBlank() }

    fun save(onDone: (Long) -> Unit) {
        val entries = rows.filter { it.english.isNotBlank() && it.spanish.isNotBlank() }
            .map { ParsedEntry(it.english, it.spanish, it.pronunciation.ifBlank { null }, it.topic.ifBlank { null }) }
        if (entries.isEmpty()) { error = "No hay ninguna palabra completa para guardar."; return }
        if (targetDeckId == null && deckName.isBlank()) deckName = "Mi lista"
        saving = true
        viewModelScope.launch {
            try {
                val id = container.repository.saveImport(deckName, source, targetDeckId, entries)
                onDone(id)
            } catch (e: Exception) {
                error = "No se ha podido guardar: ${e.localizedMessage}"
            } finally {
                saving = false
            }
        }
    }
}
