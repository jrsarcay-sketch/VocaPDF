package es.vocapdf.app.ui.games

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import es.vocapdf.app.appContainer
import es.vocapdf.app.ui.components.BigButton
import es.vocapdf.app.ui.components.DeckSelector
import es.vocapdf.app.ui.components.EmptyState
import es.vocapdf.app.ui.study.ResultPanel
import es.vocapdf.app.ui.theme.Bad
import es.vocapdf.app.ui.theme.Good

// ============================================================== lista de juegos

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GamesScreen(onPlay: (GameMode, Long?) -> Unit) {
    val container = appContainer()
    val decksFlow = remember { container.repository.allDecks() }
    val decks by decksFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    var deckId by rememberSaveable { mutableStateOf<Long?>(null) }

    Scaffold(topBar = { TopAppBar(title = { Text("Jugar") }) }) { padding ->
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Text("Practica con juegos rápidos", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                DeckSelector(decks, deckId, { deckId = it })
            }
            items(GameMode.entries) { mode ->
                val highlight = mode == GameMode.DAILY
                Card(
                    Modifier.fillMaxWidth().clickable { onPlay(mode, deckId) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (highlight) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                    ),
                    border = if (highlight) null else BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(mode.emoji, fontSize = 32.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(mode.title, style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (mode == GameMode.DAILY) "${mode.description} (con todas tus listas)" else mode.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============================================================== partida

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(mode: GameMode, deckId: Long?, onExit: () -> Unit) {
    val container = appContainer()
    val vm: GameViewModel = viewModel(factory = viewModelFactory { initializer { GameViewModel(container, mode, deckId) } })

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${mode.emoji} ${mode.title}") },
                navigationIcon = {
                    IconButton(onClick = { if (vm.phase == GameViewModel.Phase.PLAYING && vm.answered > 0) vm.quit() else onExit() }) {
                        Icon(Icons.Filled.Close, "Salir")
                    }
                },
                actions = {
                    if (vm.phase == GameViewModel.Phase.PLAYING) {
                        Text("⭐ ${vm.score}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(end = 16.dp))
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (vm.phase) {
                GameViewModel.Phase.LOADING -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                GameViewModel.Phase.NOT_ENOUGH -> EmptyState(
                    "📚", "Faltan palabras",
                    "Necesitas al menos 4 palabras en la lista para jugar. Importa un PDF o añade palabras.",
                ) { OutlinedButton(onClick = onExit) { Text("Volver") } }
                GameViewModel.Phase.PLAYING -> if (mode == GameMode.MATCH) MatchBoard(vm) else QuestionBoard(vm)
                GameViewModel.Phase.DONE -> ResultPanel(
                    emoji = when {
                        vm.answered == 0 -> "👋"
                        vm.accuracy == 100 -> "💯"
                        vm.accuracy >= 70 -> "🏆"
                        else -> "🌟"
                    },
                    title = when (mode) {
                        GameMode.TIMED -> "¡Tiempo! ${vm.correctCount} aciertos"
                        GameMode.DAILY -> "¡Reto completado!"
                        else -> "¡Partida terminada!"
                    },
                    message = when {
                        vm.answered == 0 -> "¡Vuelve cuando quieras!"
                        vm.accuracy == 100 -> "¡Perfecto, sin un solo fallo! Eres una máquina."
                        vm.accuracy >= 70 -> "¡Muy bien! Las que has fallado volverán pronto para que las repases."
                        else -> "¡Buen intento! Cada error es una oportunidad: esas palabras saldrán antes en tus repasos."
                    },
                    stats = listOf("${vm.score}" to "puntos", "${vm.accuracy} %" to "aciertos", "+${vm.xp}" to "XP"),
                    extra = when {
                        vm.newRecord -> "🥇 ¡Nuevo récord personal!"
                        vm.goalReachedNow -> "🎯 ¡Objetivo diario cumplido! +50 XP de bonus"
                        else -> null
                    },
                    primary = "Jugar otra vez" to { vm.restart() },
                    secondary = "Salir" to onExit,
                )
            }
        }
    }
}

@Composable
private fun QuestionBoard(vm: GameViewModel) {
    val q = vm.question ?: return
    val fb = vm.feedback
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(fb) { if (fb != null && !fb.correct) haptic.performHapticFeedback(HapticFeedbackType.LongPress) }

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (vm.mode == GameMode.TIMED) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("⏱️ ${vm.secondsLeft} s", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                Text("✅ ${vm.correctCount}", style = MaterialTheme.typography.titleLarge)
            }
            LinearProgressIndicator(progress = { vm.secondsLeft / 60f }, Modifier.fillMaxWidth().height(8.dp), strokeCap = StrokeCap.Round)
        } else {
            Text("Pregunta ${vm.index} de ${vm.total}" + if (vm.combo >= 3) "   🔥 x${vm.combo}" else "", style = MaterialTheme.typography.labelLarge)
            LinearProgressIndicator(progress = { (vm.index - 1).toFloat() / vm.total.coerceAtLeast(1) }, Modifier.fillMaxWidth().height(8.dp), strokeCap = StrokeCap.Round)
        }

        when (q) {
            is Question.Choice -> ChoiceQuestion(vm, q, fb)
            is Question.Typed -> TypedQuestion(vm, q, fb)
            is Question.Scramble -> ScrambleQuestion(vm, q, fb)
        }

        if (fb != null) {
            FeedbackCard(fb)
            if (vm.mode != GameMode.TIMED) BigButton(if (vm.index >= vm.total) "Ver resultado" else "Siguiente", { vm.next() })
        }
    }
}

@Composable
private fun PromptCard(label: String, text: String, speakable: Boolean, masked: String? = null) {
    val container = appContainer()
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            Text(text, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
            masked?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, fontFamily = FontFamily.Monospace, fontSize = 26.sp, letterSpacing = 4.sp, textAlign = TextAlign.Center)
            }
            if (speakable) {
                IconButton(onClick = { container.speaker.speak(text) }) { Icon(Icons.AutoMirrored.Filled.VolumeUp, "Escuchar") }
            }
        }
    }
}

@Composable
private fun ChoiceQuestion(vm: GameViewModel, q: Question.Choice, fb: Feedback?) {
    PromptCard(if (q.toEnglish) "¿Cómo se dice en inglés?" else "¿Qué significa?", q.prompt, speakable = !q.toEnglish)
    q.options.forEach { opt ->
        val color = when {
            fb == null -> MaterialTheme.colorScheme.surface
            opt == q.answer -> Good.copy(alpha = 0.25f)
            else -> MaterialTheme.colorScheme.surface
        }
        Surface(
            onClick = { vm.answerChoice(opt) },
            enabled = fb == null,
            shape = MaterialTheme.shapes.medium,
            color = color,
            border = BorderStroke(2.dp, if (fb != null && opt == q.answer) Good else MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth().heightIn(min = 58.dp),
        ) {
            Box(Modifier.padding(16.dp), contentAlignment = Alignment.CenterStart) {
                Text(opt, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
private fun TypedQuestion(vm: GameViewModel, q: Question.Typed, fb: Feedback?) {
    val focus = remember { FocusRequester() }
    PromptCard(
        label = when {
            q.masked != null -> "Completa la palabra en inglés"
            q.toEnglish -> "Escríbelo en inglés"
            else -> "Escríbelo en español"
        },
        text = q.prompt,
        speakable = !q.toEnglish,
        masked = q.masked,
    )
    OutlinedTextField(
        value = vm.typed,
        onValueChange = { vm.typed = it },
        enabled = fb == null,
        singleLine = true,
        label = { Text("Tu respuesta") },
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrectEnabled = false, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { vm.answerTyped() }),
        modifier = Modifier.fillMaxWidth().focusRequester(focus),
    )
    LaunchedEffect(q) { runCatching { focus.requestFocus() } }
    if (fb == null) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { vm.skip() }, modifier = Modifier.weight(1f).heightIn(min = 52.dp)) { Text("No lo sé") }
            BigButton("Comprobar", { vm.answerTyped() }, Modifier.weight(1f), enabled = vm.typed.isNotBlank())
        }
    }
}

@Composable
private fun ScrambleQuestion(vm: GameViewModel, q: Question.Scramble, fb: Feedback?) {
    PromptCard("Forma la palabra en inglés", q.word.spanish, speakable = false)
    // Respuesta formada
    Card(Modifier.fillMaxWidth()) {
        Text(
            vm.scrambleSelected.map { q.letters[it] }.joinToString("").ifEmpty { "…" },
            fontFamily = FontFamily.Monospace,
            fontSize = 28.sp,
            letterSpacing = 3.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(18.dp),
        )
    }
    // Letras (filas de 6)
    q.letters.indices.chunked(6).forEach { rowIdx ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), modifier = Modifier.fillMaxWidth()) {
            rowIdx.forEach { i ->
                val used = i in vm.scrambleSelected
                Surface(
                    onClick = { vm.tapScrambleLetter(i) },
                    enabled = fb == null,
                    shape = MaterialTheme.shapes.small,
                    color = if (used) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.size(48.dp),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            q.letters[i].uppercase(),
                            fontSize = 22.sp,
                            color = if (used) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSecondaryContainer,
                        )
                    }
                }
            }
        }
    }
    if (fb == null) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { vm.clearScramble() }, modifier = Modifier.weight(1f)) { Text("Borrar") }
            OutlinedButton(onClick = { vm.skip() }, modifier = Modifier.weight(1f)) { Text("No lo sé") }
        }
    }
}

@Composable
private fun FeedbackCard(fb: Feedback) {
    val (bg, title) = when {
        fb.correct && fb.close -> Good to "¡Casi perfecto! ✍️"
        fb.correct -> Good to listOf("¡Correcto! 🎉", "¡Genial! ✨", "¡Muy bien! 👏", "¡Eso es! 💪").random()
        else -> Bad to "¡Ups! No pasa nada 💛"
    }
    Card(colors = CardDefaults.cardColors(containerColor = bg.copy(alpha = 0.18f)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = if (fb.correct) Good else Bad)
            if (!fb.correct || fb.close) Text("Respuesta: ${fb.rightAnswer}", style = MaterialTheme.typography.bodyLarge)
        }
    }
}

// ============================================================== emparejar

@Composable
private fun MatchBoard(vm: GameViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            "Ronda ${vm.matchRound + 1} · Toca una palabra inglesa y luego su traducción" + if (vm.combo >= 3) "   🔥 x${vm.combo}" else "",
            style = MaterialTheme.typography.labelLarge,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                vm.leftTiles.forEach { t ->
                    MatchTileView(t, selected = vm.selectedLeft == t.wordId, wrong = vm.wrongFlash?.first == t.wordId) { vm.tapLeft(t.wordId) }
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                vm.rightTiles.forEach { t ->
                    MatchTileView(t, selected = false, wrong = vm.wrongFlash?.second == t.wordId) { vm.tapRight(t.wordId) }
                }
            }
        }
        if (vm.answered > 0) {
            TextButton(onClick = { vm.quit() }) { Text("Terminar partida") }
        }
    }
}

@Composable
private fun MatchTileView(t: MatchTile, selected: Boolean, wrong: Boolean, onClick: () -> Unit) {
    val bg = when {
        t.solved -> Good.copy(alpha = 0.2f)
        wrong -> Bad.copy(alpha = 0.25f)
        selected -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surface
    }
    val border = when {
        t.solved -> Good
        wrong -> Bad
        selected -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    Surface(
        onClick = onClick,
        enabled = !t.solved,
        shape = MaterialTheme.shapes.medium,
        color = bg,
        border = BorderStroke(2.dp, border),
        modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp),
    ) {
        Box(Modifier.padding(10.dp), contentAlignment = Alignment.Center) {
            Text(
                t.text,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyLarge,
                color = if (t.solved) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f) else Color.Unspecified,
            )
        }
    }
}
