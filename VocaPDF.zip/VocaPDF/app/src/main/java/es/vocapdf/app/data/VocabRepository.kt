package es.vocapdf.app.data

import androidx.room.withTransaction
import es.vocapdf.app.data.backup.BackupRow
import es.vocapdf.app.data.backup.CsvBackup
import es.vocapdf.app.data.db.AppDatabase
import es.vocapdf.app.data.db.DailyStat
import es.vocapdf.app.data.db.Deck
import es.vocapdf.app.data.db.ReviewLog
import es.vocapdf.app.data.db.Word
import es.vocapdf.app.domain.Gamification
import es.vocapdf.app.domain.Grade
import es.vocapdf.app.domain.LevelInfo
import es.vocapdf.app.domain.Medal
import es.vocapdf.app.domain.MedalInput
import es.vocapdf.app.domain.Srs
import es.vocapdf.app.domain.TextMatch
import es.vocapdf.app.pdf.ParsedEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate

/** Resultado de importar un CSV. */
data class RestoreResult(val decksCreated: Int, val wordsAdded: Int, val duplicates: Int, val skippedLines: Int) {
    val message: String get() = buildString {
        append("Importadas $wordsAdded palabras")
        if (decksCreated > 0) append(" en $decksCreated listas nuevas")
        append(".")
        if (duplicates > 0) append(" $duplicates ya existían y se han omitido.")
        if (skippedLines > 0) append(" $skippedLines líneas incompletas ignoradas.")
    }
}

/** Resultado de responder una pregunta o tarjeta. */
data class AnswerOutcome(val xpGained: Int, val goalJustReached: Boolean)

/** Resumen global para Inicio y Progreso. */
data class Overview(
    val totalWords: Int,
    val learned: Int,
    val due: Int,
    val decks: Int,
    val today: DailyStat,
    val totalXp: Int,
    val level: LevelInfo,
    val streak: Int,
    val bestStreak: Int,
    val answered: Int,
    val correct: Int,
    val secondsStudied: Long,
    /** Últimos 7 días, del más antiguo a hoy. */
    val last7: List<Pair<LocalDate, Int>>,
    val medals: List<Medal>,
    val settings: Settings,
) {
    val accuracy: Int get() = if (answered == 0) 0 else (correct * 100 / answered)
}

class VocabRepository(private val db: AppDatabase, private val settingsRepo: SettingsRepository) {

    private val decks = db.deckDao()
    private val words = db.wordDao()
    private val stats = db.statsDao()
    private val statsMutex = Mutex()

    // ------------------------------------------------------------------ listas y palabras

    fun deckSummaries() = decks.observeSummaries(System.currentTimeMillis())
    fun allDecks() = decks.observeAll()
    fun deck(id: Long) = decks.observe(id)
    fun wordsOfDeck(id: Long) = words.observeByDeck(id)

    suspend fun saveImport(name: String, source: String?, targetDeckId: Long?, entries: List<ParsedEntry>): Long =
        db.withTransaction {
            val deckId = targetDeckId ?: decks.insert(Deck(name = name.trim().ifBlank { "Mi lista" }, source = source))
            words.insertAll(
                entries.map {
                    Word(
                        deckId = deckId,
                        english = it.english.trim(),
                        spanish = it.spanish.trim(),
                        pronunciation = it.pronunciation?.trim()?.takeIf(String::isNotEmpty),
                        topic = it.topic?.trim()?.takeIf(String::isNotEmpty),
                    )
                },
            )
            deckId
        }

    suspend fun createDeck(name: String): Long = decks.insert(Deck(name = name.trim().ifBlank { "Mi lista" }))
    suspend fun renameDeck(id: Long, name: String) = decks.rename(id, name.trim())
    suspend fun deleteDeck(id: Long) = decks.delete(id)

    suspend fun addWord(deckId: Long, en: String, es: String, pron: String?, topic: String?) {
        words.insert(Word(deckId = deckId, english = en.trim(), spanish = es.trim(), pronunciation = pron?.trim()?.ifBlank { null }, topic = topic?.trim()?.ifBlank { null }))
    }

    suspend fun updateWord(w: Word) = words.update(w)
    suspend fun deleteWord(w: Word) = words.delete(w)

    // ------------------------------------------------------------------ copia de seguridad CSV

    suspend fun exportCsv(deckId: Long?): String {
        val names = decks.all().associate { it.id to it.name }
        val rows = words.allWords(deckId).map { w ->
            BackupRow(names[w.deckId], w.english, w.spanish, w.pronunciation, w.topic, w.srs)
        }
        return CsvBackup.write(rows)
    }

    /**
     * Importa un CSV. Las filas con columna "lista" van a la lista de ese nombre (se crea si no
     * existe); el resto, a [fallbackDeckName]. Las palabras repetidas se omiten.
     */
    suspend fun importCsv(text: String, fallbackDeckName: String): RestoreResult {
        val parsed = CsvBackup.parse(text)
        if (parsed.rows.isEmpty()) return RestoreResult(0, 0, 0, parsed.skippedLines)
        return db.withTransaction {
            val deckIds = decks.all().associate { TextMatch.normalize(it.name) to it.id }.toMutableMap()
            val known = HashMap<Long, MutableSet<String>>()
            var created = 0
            var added = 0
            var dupes = 0
            val toInsert = mutableListOf<Word>()
            for (r in parsed.rows) {
                val name = r.deck?.trim()?.takeIf { it.isNotEmpty() } ?: fallbackDeckName.ifBlank { "Lista importada" }
                val key = TextMatch.normalize(name)
                val deckId = deckIds[key] ?: decks.insert(Deck(name = name, source = "CSV")).also { deckIds[key] = it; created++ }
                val existing = known.getOrPut(deckId) {
                    words.allWords(deckId).mapTo(HashSet()) { wordKey(it.english, it.spanish) }
                }
                if (!existing.add(wordKey(r.english, r.spanish))) { dupes++; continue }
                val base = Word(deckId = deckId, english = r.english, spanish = r.spanish, pronunciation = r.pronunciation, topic = r.topic)
                toInsert += r.srs?.let { base.withSrs(it) } ?: base
                added++
            }
            words.insertAll(toInsert)
            RestoreResult(created, added, dupes, parsed.skippedLines)
        }
    }

    private fun wordKey(en: String, es: String) = TextMatch.normalize(en) + "|" + TextMatch.normalize(es)

    // ------------------------------------------------------------------ estudio

    suspend fun studyQueue(deckId: Long?, limit: Int): List<Word> = words.due(deckId, System.currentTimeMillis(), limit)
    suspend fun extraPractice(deckId: Long?, limit: Int): List<Word> = words.weakest(deckId, limit)
    suspend fun gameWords(deckId: Long?, limit: Int): List<Word> = words.forGames(deckId, limit)
    suspend fun randomWords(deckId: Long?, limit: Int): List<Word> = words.random(deckId, limit)
    suspend fun wordCount(deckId: Long?): Int = words.count(deckId)
    suspend fun dueCount(): Int = words.dueCount(System.currentTimeMillis())

    /** Respuesta en tarjetas: actualiza la repetición espaciada. */
    suspend fun gradeCard(word: Word, grade: Grade): AnswerOutcome {
        val now = System.currentTimeMillis()
        val fresh = words.get(word.id) ?: return AnswerOutcome(0, false)
        words.update(fresh.withSrs(Srs.schedule(fresh.srs, grade, now)))
        stats.log(ReviewLog(wordId = word.id, day = Srs.dayKey(now), timestamp = now, mode = "tarjetas", correct = grade != Grade.AGAIN))
        return bumpStats(correct = grade != Grade.AGAIN, xp = Gamification.xpFor(grade))
    }

    /** Respuesta en un juego: un fallo hace que la palabra vuelva antes. */
    suspend fun recordGameAnswer(word: Word, correct: Boolean, mode: String): AnswerOutcome {
        val now = System.currentTimeMillis()
        if (!correct) {
            words.get(word.id)?.let { fresh -> words.update(fresh.withSrs(Srs.penalize(fresh.srs, now))) }
        }
        stats.log(ReviewLog(wordId = word.id, day = Srs.dayKey(now), timestamp = now, mode = mode, correct = correct))
        return bumpStats(correct, Gamification.xpForGame(correct))
    }

    private suspend fun bumpStats(correct: Boolean, xp: Int): AnswerOutcome = statsMutex.withLock {
        val goal = settingsRepo.current().dailyGoal
        val day = Srs.dayKey()
        val cur = stats.get(day) ?: DailyStat(day)
        var next = cur.copy(reviewed = cur.reviewed + 1, correct = cur.correct + if (correct) 1 else 0, xp = cur.xp + xp)
        var gained = xp
        var goalNow = false
        if (!cur.goalReached && next.reviewed >= goal) {
            next = next.copy(goalReached = true, xp = next.xp + Gamification.GOAL_BONUS)
            gained += Gamification.GOAL_BONUS
            goalNow = true
        }
        stats.upsert(next)
        AnswerOutcome(gained, goalNow)
    }

    suspend fun addStudyTime(seconds: Long) = statsMutex.withLock {
        if (seconds <= 0) return@withLock
        val day = Srs.dayKey()
        val cur = stats.get(day) ?: DailyStat(day)
        stats.upsert(cur.copy(secondsStudied = cur.secondsStudied + seconds))
    }

    suspend fun saveChallengeScore(score: Int) = statsMutex.withLock {
        val day = Srs.dayKey()
        val cur = stats.get(day) ?: DailyStat(day)
        stats.upsert(cur.copy(challengeScore = maxOf(score, cur.challengeScore ?: 0)))
    }

    suspend fun todayChallengeScore(): Int? = stats.get(Srs.dayKey())?.challengeScore

    suspend fun todayStat(): DailyStat = Srs.dayKey().let { stats.get(it) ?: DailyStat(it) }

    suspend fun resetProgress() = db.withTransaction {
        words.resetProgress()
        stats.clearStats()
        stats.clearLog()
    }

    // ------------------------------------------------------------------ resumen

    fun overview(): Flow<Overview> = combine(
        words.observeCounts(System.currentTimeMillis()),
        stats.observeAll(),
        settingsRepo.settings,
    ) { counts, all, settings ->
        val todayDate = Srs.today()
        val todayKey = todayDate.toString()
        val byDay = all.associateBy { it.day }
        val studyDays = all.filter { it.reviewed > 0 }.mapNotNull { runCatching { LocalDate.parse(it.day) }.getOrNull() }.toSet()
        val totalXp = all.sumOf { it.xp }
        val streak = Gamification.currentStreak(studyDays, todayDate)
        val best = Gamification.bestStreak(studyDays)
        val answered = all.sumOf { it.reviewed }
        val correct = all.sumOf { it.correct }
        val last7 = (6 downTo 0).map { back ->
            val d = todayDate.minusDays(back.toLong())
            d to (byDay[d.toString()]?.reviewed ?: 0)
        }
        val medals = Gamification.medals(
            MedalInput(
                totalWords = counts.total,
                learned = counts.learned,
                decks = counts.decks,
                streak = streak,
                bestStreak = best,
                totalXp = totalXp,
                answered = answered,
                perfectGames = settings.perfectGames,
                challengesDone = all.count { it.challengeScore != null },
                goalDays = all.count { it.goalReached },
            ),
        )
        Overview(
            totalWords = counts.total,
            learned = counts.learned,
            due = counts.due,
            decks = counts.decks,
            today = byDay[todayKey] ?: DailyStat(todayKey),
            totalXp = totalXp,
            level = Gamification.level(totalXp),
            streak = streak,
            bestStreak = best,
            answered = answered,
            correct = correct,
            secondsStudied = all.sumOf { it.secondsStudied },
            last7 = last7,
            medals = medals,
            settings = settings,
        )
    }
}
