package es.vocapdf.app.ui.games

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import es.vocapdf.app.AppContainer
import es.vocapdf.app.data.db.Word
import es.vocapdf.app.domain.MatchResult
import es.vocapdf.app.domain.TextMatch
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class GameMode(val emoji: String, val title: String, val description: String) {
    CHOICE("🎯", "Elección múltiple", "Elige la traducción correcta entre 4 opciones"),
    TRANSLATE_TO_ES("🇪🇸", "Traduce al español", "Lee la palabra en inglés y escribe su traducción"),
    TRANSLATE_TO_EN("🇬🇧", "Traduce al inglés", "Lee la palabra en español y escríbela en inglés"),
    COMPLETE("🧩", "Completa la palabra", "Rellena las letras que faltan"),
    MATCH("🔗", "Empareja", "Une cada palabra inglesa con su traducción"),
    SCRAMBLE("🔤", "Ordena las letras", "Forma la palabra inglesa con letras desordenadas"),
    TIMED("⏱️", "Contrarreloj", "¿Cuántas aciertas en 60 segundos?"),
    DAILY("🏆", "Reto diario", "10 preguntas variadas para ganar puntos"),
}

/** Una pregunta de juego. */
sealed interface Question {
    val word: Word

    /** Elegir entre opciones. [toEnglish] = el enunciado está en español. */
    data class Choice(override val word: Word, val prompt: String, val options: List<String>, val answer: String, val toEnglish: Boolean) : Question

    /** Escribir la respuesta. [masked] se usa en "completar la palabra". */
    data class Typed(override val word: Word, val prompt: String, val expected: String, val toEnglish: Boolean, val masked: String? = null) : Question

    /** Formar la palabra con letras. */
    data class Scramble(override val word: Word, val letters: List<Char>, val expected: String) : Question
}

data class Feedback(val correct: Boolean, val close: Boolean, val rightAnswer: String)

/** Estado del juego de emparejar. */
data class MatchTile(val wordId: Long, val text: String, val english: Boolean, val solved: Boolean = false)

class GameViewModel(private val container: AppContainer, val mode: GameMode, private val deckId: Long?) : ViewModel() {

    enum class Phase { LOADING, NOT_ENOUGH, PLAYING, DONE }

    var phase by mutableStateOf(Phase.LOADING); private set
    var question by mutableStateOf<Question?>(null); private set
    var feedback by mutableStateOf<Feedback?>(null); private set
    var index by mutableIntStateOf(0); private set
    var total by mutableIntStateOf(0); private set
    var score by mutableIntStateOf(0); private set
    var correctCount by mutableIntStateOf(0); private set
    var answered by mutableIntStateOf(0); private set
    var combo by mutableIntStateOf(0); private set
    var xp by mutableIntStateOf(0); private set
    var secondsLeft by mutableIntStateOf(60); private set
    var newRecord by mutableStateOf(false); private set
    var goalReachedNow by mutableStateOf(false); private set
    var typed by mutableStateOf("")
    val scrambleSelected = mutableStateListOf<Int>()

    // Emparejar
    val leftTiles = mutableStateListOf<MatchTile>()
    val rightTiles = mutableStateListOf<MatchTile>()
    var selectedLeft by mutableStateOf<Long?>(null); private set
    var wrongFlash by mutableStateOf<Pair<Long, Long>?>(null); private set
    private val matchMistakes = HashSet<Long>()
    private var matchRounds: List<List<Word>> = emptyList()
    var matchRound by mutableIntStateOf(0); private set

    private var pool: List<Word> = emptyList()
    private var distractors: List<Word> = emptyList()
    private var questions: MutableList<Question> = mutableListOf()
    private var timerJob: Job? = null
    private var startedAt = System.currentTimeMillis()
    private val rnd = Random(System.nanoTime())

    init { load() }

    private fun load() = viewModelScope.launch {
        val effectiveDeck = if (mode == GameMode.DAILY) null else deckId
        val count = container.repository.wordCount(effectiveDeck)
        if (count < 4) { phase = Phase.NOT_ENOUGH; return@launch }
        pool = container.repository.gameWords(effectiveDeck, if (mode == GameMode.TIMED) 80 else 30)
        distractors = container.repository.randomWords(effectiveDeck, 300)
        when (mode) {
            GameMode.MATCH -> {
                matchRounds = pool.take(10).chunked(5).filter { it.size >= 3 }
                total = matchRounds.sumOf { it.size }
                startMatchRound()
            }
            GameMode.TIMED -> {
                total = 0
                startTimer()
                nextQuestion()
            }
            else -> {
                questions = pool.take(10).map { build(it, mode) }.toMutableList()
                total = questions.size
                nextQuestion()
            }
        }
        phase = Phase.PLAYING
    }

    // ------------------------------------------------------------------ preguntas

    private fun build(w: Word, m: GameMode): Question = when (m) {
        GameMode.CHOICE -> choice(w, toEnglish = false)
        GameMode.TIMED -> choice(w, toEnglish = rnd.nextInt(3) == 0)
        GameMode.TRANSLATE_TO_ES -> Question.Typed(w, w.english, w.spanish, toEnglish = false)
        GameMode.TRANSLATE_TO_EN -> Question.Typed(w, w.spanish, w.english, toEnglish = true)
        GameMode.COMPLETE -> Question.Typed(w, w.spanish, w.english, toEnglish = true, masked = mask(w.english))
        GameMode.SCRAMBLE -> scramble(w) ?: choice(w, toEnglish = true)
        GameMode.DAILY -> when (rnd.nextInt(4)) {
            0 -> choice(w, toEnglish = false)
            1 -> choice(w, toEnglish = true)
            2 -> scramble(w) ?: Question.Typed(w, w.spanish, w.english, toEnglish = true, masked = mask(w.english))
            else -> Question.Typed(w, w.english, w.spanish, toEnglish = false)
        }
        GameMode.MATCH -> choice(w, toEnglish = false) // no se usa
    }

    private fun choice(w: Word, toEnglish: Boolean): Question.Choice {
        val answer = if (toEnglish) w.english else w.spanish
        val seen = hashSetOf(TextMatch.normalize(answer))
        val others = distractors.shuffled(rnd).mapNotNull { d ->
            val t = if (toEnglish) d.english else d.spanish
            if (d.id != w.id && seen.add(TextMatch.normalize(t))) t else null
        }.take(3)
        val options = (others + answer).shuffled(rnd)
        return Question.Choice(w, if (toEnglish) w.spanish else w.english, options, answer, toEnglish)
    }

    private fun scramble(w: Word): Question.Scramble? {
        val target = w.english.trim()
        val letters = target.filter { it.isLetter() }
        if (letters.length !in 3..14 || target.any { !it.isLetter() && it != '-' && it != '\'' }) return null
        var shuffled = letters.toList().shuffled(rnd)
        var tries = 0
        while (shuffled.joinToString("") == letters && tries++ < 10) shuffled = letters.toList().shuffled(rnd)
        return Question.Scramble(w, shuffled.map { it.lowercaseChar() }, letters.lowercase())
    }

    /** Oculta ~40 % de las letras, dejando siempre la primera. */
    private fun mask(text: String): String {
        val letterIdx = text.indices.filter { text[it].isLetter() }
        if (letterIdx.size <= 2) return text.mapIndexed { i, c -> if (i == letterIdx.lastOrNull()) '_' else c }.joinToString("")
        val hideCount = (letterIdx.size * 0.4).toInt().coerceAtLeast(1)
        val hide = letterIdx.drop(1).shuffled(rnd).take(hideCount).toSet()
        return text.mapIndexed { i, c -> if (i in hide) '_' else c }.joinToString("")
    }

    private fun nextQuestion() {
        feedback = null
        typed = ""
        scrambleSelected.clear()
        if (mode == GameMode.TIMED) {
            if (pool.isEmpty()) return
            question = build(if (index < pool.size) pool[index] else pool.random(rnd), mode)
            index++
            return
        }
        val q = questions.getOrNull(index)
        if (q == null) { finish(); return }
        question = q
        index++
    }

    // ------------------------------------------------------------------ respuestas

    fun answerChoice(option: String) {
        val q = question as? Question.Choice ?: return
        if (feedback != null) return
        submit(q.word, option == q.answer, false, q.answer)
    }

    fun answerTyped() {
        val q = question as? Question.Typed ?: return
        if (feedback != null || typed.isBlank()) return
        val r = TextMatch.check(typed, q.expected)
        submit(q.word, r != MatchResult.WRONG, r == MatchResult.CLOSE, q.expected)
    }

    fun tapScrambleLetter(i: Int) {
        if (feedback != null) return
        if (i in scrambleSelected) scrambleSelected.remove(i) else scrambleSelected.add(i)
        val q = question as? Question.Scramble ?: return
        if (scrambleSelected.size == q.letters.size) {
            val formed = scrambleSelected.map { q.letters[it] }.joinToString("")
            submit(q.word, formed == q.expected, false, q.word.english)
        }
    }

    fun clearScramble() { if (feedback == null) scrambleSelected.clear() }

    fun skip() {
        val q = question ?: return
        if (feedback != null) return
        val right = when (q) {
            is Question.Choice -> q.answer
            is Question.Typed -> q.expected
            is Question.Scramble -> q.word.english
        }
        submit(q.word, false, false, right)
    }

    private fun submit(word: Word, correct: Boolean, close: Boolean, right: String) {
        answered++
        if (correct) {
            correctCount++
            combo++
            score += 10 + (combo - 1).coerceAtMost(5) * 2
        } else {
            combo = 0
        }
        feedback = Feedback(correct, close, right)
        if (correct) container.speaker.speak(word.english)
        record(word, correct)
        if (mode == GameMode.TIMED) {
            total = answered
            viewModelScope.launch { delay(if (correct) 450 else 1100); if (phase == Phase.PLAYING) nextQuestion() }
        }
    }

    fun next() = nextQuestion()

    private fun record(word: Word, correct: Boolean) {
        viewModelScope.launch {
            val out = container.repository.recordGameAnswer(word, correct, mode.name.lowercase())
            xp += out.xpGained
            if (out.goalJustReached) goalReachedNow = true
        }
    }

    // ------------------------------------------------------------------ emparejar

    private fun startMatchRound() {
        val round = matchRounds.getOrNull(matchRound)
        if (round == null) { finish(); return }
        leftTiles.clear(); rightTiles.clear(); matchMistakes.clear()
        leftTiles.addAll(round.map { MatchTile(it.id, it.english, true) }.shuffled(rnd))
        rightTiles.addAll(round.map { MatchTile(it.id, it.spanish, false) }.shuffled(rnd))
        selectedLeft = null
    }

    fun tapLeft(id: Long) {
        if (leftTiles.firstOrNull { it.wordId == id }?.solved == true) return
        selectedLeft = id
        pool.firstOrNull { it.id == id }?.let { container.speaker.speak(it.english) }
    }

    fun tapRight(id: Long) {
        val left = selectedLeft ?: return
        if (rightTiles.firstOrNull { it.wordId == id }?.solved == true) return
        val word = pool.first { it.id == left }
        if (id == left) {
            val firstTry = left !in matchMistakes
            markSolved(leftTiles, id)
            markSolved(rightTiles, id)
            selectedLeft = null
            answered++
            if (firstTry) { correctCount++; combo++; score += 10 + (combo - 1).coerceAtMost(5) * 2 } else combo = 0
            record(word, firstTry)
            if (leftTiles.all { it.solved }) {
                viewModelScope.launch { delay(500); matchRound++; startMatchRound() }
            }
        } else {
            matchMistakes += left
            combo = 0
            wrongFlash = left to id
            viewModelScope.launch { delay(600); wrongFlash = null }
        }
    }

    private fun markSolved(list: MutableList<MatchTile>, id: Long) {
        for (i in list.indices) if (list[i].wordId == id) list[i] = list[i].copy(solved = true)
    }

    // ------------------------------------------------------------------ fin

    private fun startTimer() {
        timerJob = viewModelScope.launch {
            secondsLeft = 60
            while (secondsLeft > 0) { delay(1000); secondsLeft-- }
            finish()
        }
    }

    private fun finish() {
        if (phase == Phase.DONE) return
        timerJob?.cancel()
        question = null
        phase = Phase.DONE
        viewModelScope.launch {
            val repo = container.repository
            val settings = container.settings
            repo.addStudyTime(((System.currentTimeMillis() - startedAt) / 1000).coerceAtMost(3600))
            if (answered > 0 && correctCount == answered && mode != GameMode.TIMED) settings.addPerfectGame()
            when (mode) {
                GameMode.DAILY -> repo.saveChallengeScore(score)
                GameMode.TIMED -> newRecord = settings.submitTimedScore(correctCount)
                else -> Unit
            }
        }
    }

    fun quit() = finish()

    fun restart() {
        timerJob?.cancel()
        phase = Phase.LOADING
        question = null; feedback = null
        index = 0; total = 0; score = 0; correctCount = 0; answered = 0; combo = 0; xp = 0
        secondsLeft = 60; newRecord = false; goalReachedNow = false; typed = ""
        scrambleSelected.clear(); leftTiles.clear(); rightTiles.clear(); matchRound = 0
        selectedLeft = null; wrongFlash = null
        startedAt = System.currentTimeMillis()
        load()
    }

    val accuracy: Int get() = if (answered == 0) 0 else correctCount * 100 / answered
}
