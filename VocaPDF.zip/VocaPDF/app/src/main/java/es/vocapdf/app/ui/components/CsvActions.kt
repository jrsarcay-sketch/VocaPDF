package es.vocapdf.app.ui.components

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import es.vocapdf.app.appContainer
import es.vocapdf.app.pdf.PdfTextExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

/** Acciones de exportar e importar CSV listas para usar en cualquier pantalla. */
class CsvActions(
    /** Exporta una lista (o todas si es null). [fileName] sin extensión. */
    val export: (deckId: Long?, fileName: String) -> Unit,
    /** Abre el selector de archivos e importa un CSV. */
    val import: () -> Unit,
    val busy: Boolean,
)

@Composable
fun rememberCsvActions(onImported: (String) -> Unit = {}): CsvActions {
    val context = LocalContext.current
    val container = appContainer()
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var pendingExportDeck by remember { mutableStateOf<Long?>(null) }

    val createDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        scope.launch {
            val msg = try {
                val csv = container.repository.exportCsv(pendingExportDeck)
                writeText(context, uri, csv)
                "Copia guardada ✔"
            } catch (e: Exception) {
                "No se ha podido guardar: ${e.localizedMessage}"
            }
            busy = false
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
        }
    }

    val openDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        scope.launch {
            val msg = try {
                val text = readText(context, uri)
                val name = PdfTextExtractor(context).displayName(uri)?.substringBeforeLast('.')?.replace('_', ' ')?.trim()
                val result = container.repository.importCsv(text, name ?: "Lista importada")
                if (result.wordsAdded == 0 && result.duplicates == 0) "No se han encontrado palabras en el archivo."
                else result.message
            } catch (e: Exception) {
                "No se ha podido leer el archivo: ${e.localizedMessage}"
            }
            busy = false
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            onImported(msg)
        }
    }

    return CsvActions(
        export = { deckId, fileName ->
            pendingExportDeck = deckId
            val safe = fileName.replace(Regex("""[\\/:*?"<>|]"""), "_").ifBlank { "vocapdf" }
            createDoc.launch("$safe.csv")
        },
        import = {
            openDoc.launch(
                arrayOf("text/csv", "text/comma-separated-values", "text/plain", "text/tab-separated-values", "application/csv", "application/vnd.ms-excel"),
            )
        },
        busy = busy,
    )
}

fun backupFileName(): String = "VocaPDF_copia_${LocalDate.now()}"

private suspend fun writeText(context: Context, uri: Uri, text: String) = withContext(Dispatchers.IO) {
    val out = context.contentResolver.openOutputStream(uri, "wt") ?: error("no se puede escribir")
    out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
}

private suspend fun readText(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("no se puede abrir")
    if (bytes.size > 10_000_000) error("el archivo es demasiado grande")
    val utf8 = String(bytes, Charsets.UTF_8)
    // Excel antiguo guarda en Windows-1252: si hay caracteres inválidos, probamos esa codificación.
    if ('�' in utf8) String(bytes, charset("windows-1252")) else utf8
}
