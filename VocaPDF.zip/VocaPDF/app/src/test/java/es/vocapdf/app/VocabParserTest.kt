package es.vocapdf.app

import es.vocapdf.app.domain.Gamification
import es.vocapdf.app.domain.Grade
import es.vocapdf.app.domain.MatchResult
import es.vocapdf.app.domain.Srs
import es.vocapdf.app.domain.SrsState
import es.vocapdf.app.domain.TextMatch
import es.vocapdf.app.pdf.VocabParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneOffset

class VocabParserTest {

    @Test fun tableWithHeader() {
        val text = """
            Inglés	Español	Pronunciación	Tema
            house	casa	/haʊs/	Casa
            kitchen	cocina	/ˈkɪtʃɪn/	Casa
            1
        """.trimIndent()
        val r = VocabParser.parse(text)
        assertTrue(r.detectedTable)
        assertEquals(2, r.entries.size)
        assertEquals("house", r.entries[0].english)
        assertEquals("casa", r.entries[0].spanish)
        assertEquals("haʊs", r.entries[0].pronunciation)
        assertEquals("Casa", r.entries[0].topic)
    }

    @Test fun tableWithEmptyOptionalCell() {
        val r = VocabParser.parse("Inglés\tEspañol\tPronunciación\tTema\nHow much is it?\t¿Cuánto cuesta?\tFrases")
        assertEquals(null, r.entries[0].pronunciation)
        assertEquals("Frases", r.entries[0].topic)
    }

    @Test fun spanishFirstHeader() {
        val r = VocabParser.parse("Español | Inglés\nperro | dog\ngato | cat")
        assertEquals("dog", r.entries[0].english)
        assertEquals("perro", r.entries[0].spanish)
    }

    @Test fun separatorsAndTopics() {
        val text = """
            Viajes:
            1. airport - aeropuerto
            • ticket = billete
            - Where is the station? : ¿Dónde está la estación?
            T-shirt – camiseta
            luggage /ˈlʌɡɪdʒ/ → equipaje
            Unidad 3 resumen
        """.trimIndent()
        val r = VocabParser.parse(text)
        val en = r.entries.map { it.english }
        assertEquals(listOf("airport", "ticket", "Where is the station?", "T-shirt", "luggage"), en)
        assertEquals("¿Dónde está la estación?", r.entries[2].spanish)
        assertEquals("Viajes", r.entries[0].topic)
        assertEquals("ˈlʌɡɪdʒ", r.entries[4].pronunciation)
        assertEquals(listOf("Unidad 3 resumen"), r.unmatched)
    }

    @Test fun detectsReversedColumns() {
        val r = VocabParser.parse("la manzana - the apple\nel perro - the dog\nla canción - the song\nbuenos días - good morning")
        assertTrue(r.swapped)
        assertEquals("the apple", r.entries[0].english)
        assertEquals("la manzana", r.entries[0].spanish)
    }

    @Test fun normalDirectionNotSwapped() {
        val r = VocabParser.parse("dog - perro\ncat - gato\nwindow - ventana\nthank you - gracias")
        assertFalse(r.swapped)
        assertEquals("dog", r.entries[0].english)
    }

    @Test fun alternatingLines() {
        val pairs = VocabParser.pairAlternating(listOf("bread", "pan", "water", "agua"))
        assertEquals(2, pairs.size)
        assertEquals("water", pairs[1].english)
        assertEquals("agua", pairs[1].spanish)
    }

    @Test fun answerChecking() {
        assertEquals(MatchResult.EXACT, TextMatch.check("Cancion", "la canción"))
        assertEquals(MatchResult.EXACT, TextMatch.check("big", "big / large"))
        assertEquals(MatchResult.EXACT, TextMatch.check("run", "to run"))
        assertEquals(MatchResult.CLOSE, TextMatch.check("kitchem", "kitchen"))
        assertEquals(MatchResult.WRONG, TextMatch.check("cat", "dog"))
    }

    @Test fun leitnerScheduling() {
        val zone = ZoneOffset.UTC
        val now = LocalDate.of(2026, 1, 10).atTime(15, 0).toInstant(zone).toEpochMilli()
        val s1 = Srs.schedule(SrsState(), Grade.KNOW, now, zone)
        assertEquals(1, s1.box)
        assertEquals(LocalDate.of(2026, 1, 11).atStartOfDay().toInstant(zone).toEpochMilli(), s1.dueAt)
        val s2 = Srs.schedule(s1.copy(box = 3), Grade.KNOW, now, zone)
        assertEquals(4, s2.box)
        assertEquals(LocalDate.of(2026, 1, 18).atStartOfDay().toInstant(zone).toEpochMilli(), s2.dueAt)
        val s3 = Srs.schedule(s2, Grade.AGAIN, now, zone)
        assertEquals(0, s3.box)
        assertEquals(1, s3.lapses)
        val s4 = Srs.schedule(s2, Grade.ALMOST, now, zone)
        assertEquals(4, s4.box)
    }

    @Test fun levelsAndStreaks() {
        assertEquals(1, Gamification.level(0).level)
        assertEquals(2, Gamification.level(100).level)
        assertEquals(2, Gamification.level(299).level)
        assertEquals(3, Gamification.level(300).level)
        val today = LocalDate.of(2026, 3, 5)
        val days = setOf(today, today.minusDays(1), today.minusDays(2), today.minusDays(5))
        assertEquals(3, Gamification.currentStreak(days, today))
        assertEquals(2, Gamification.currentStreak(days - today, today))
        assertEquals(3, Gamification.bestStreak(days))
    }
}
