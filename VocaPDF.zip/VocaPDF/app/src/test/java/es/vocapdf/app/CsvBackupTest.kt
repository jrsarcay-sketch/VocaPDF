package es.vocapdf.app

import es.vocapdf.app.data.backup.BackupRow
import es.vocapdf.app.data.backup.CsvBackup
import es.vocapdf.app.domain.SrsState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneOffset

class CsvBackupTest {
    private val zone = ZoneOffset.UTC

    @Test fun roundTripKeepsProgressAndSpecialCharacters() {
        val due = LocalDate.of(2026, 11, 5).atStartOfDay().toInstant(zone).toEpochMilli()
        val rows = listOf(
            BackupRow("Viajes", "Where is it?", "¿Dónde está?", null, "Frases", SrsState(box = 3, dueAt = due, reviews = 5, correct = 4, lapses = 1, difficulty = 2)),
            BackupRow("Casa; cocina", "spoon", "cuchara, cucharilla", "spuːn", null, SrsState()),
            BackupRow("Casa; cocina", "say \"hi\"", "decir \"hola\"", null, null, null),
        )
        val text = CsvBackup.write(rows, zone)
        assertTrue(text.startsWith(CsvBackup.BOM))
        val parsed = CsvBackup.parse(text, zone)
        assertTrue(parsed.hasDeckColumn)
        assertEquals(3, parsed.rows.size)
        assertEquals(rows[0], parsed.rows[0])
        assertEquals("Casa; cocina", parsed.rows[1].deck)
        assertEquals("cuchara, cucharilla", parsed.rows[1].spanish)
        assertEquals("say \"hi\"", parsed.rows[2].english)
        assertNull(parsed.rows[2].srs)
    }

    @Test fun simpleExcelCsvWithCommas() {
        val parsed = CsvBackup.parse("English,Spanish\r\ndog,perro\r\ncat,gato\r\n,\r\n")
        assertFalse(parsed.hasDeckColumn)
        assertEquals(2, parsed.rows.size)
        assertEquals("perro", parsed.rows[0].spanish)
        assertNull(parsed.rows[0].deck)
    }

    @Test fun noHeaderUsesFirstTwoColumns() {
        val parsed = CsvBackup.parse("house;casa\nbook;libro;Escuela")
        assertEquals(2, parsed.rows.size)
        assertEquals("book", parsed.rows[1].english)
        assertEquals("libro", parsed.rows[1].spanish)
    }

    @Test fun spanishHeadersWithAccents() {
        val parsed = CsvBackup.parse("Tema;Español;Inglés\nCasa;cocina;kitchen")
        assertEquals("kitchen", parsed.rows[0].english)
        assertEquals("Casa", parsed.rows[0].topic)
    }
}
