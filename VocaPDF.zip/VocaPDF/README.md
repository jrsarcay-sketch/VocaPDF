# VocaPDF · Aprende inglés con tus propios PDFs

App Android para hispanohablantes (nivel principiante a intermedio) que convierte un PDF con vocabulario inglés–español en **tarjetas**, **repasos espaciados** y **juegos**. Funciona sin conexión, sin cuenta, sin anuncios y sin pagos. Todo se guarda solo en el móvil.

---

## Qué hace

| Pantalla | Para qué sirve |
|---|---|
| **Inicio** | Racha 🔥, nivel y XP, objetivo diario, botón «Repasar ahora» y «Reto diario». |
| **Mis listas** | Importar PDF, pegar/escribir palabras, ver y editar cada lista («mazo»). |
| **Estudiar** | Tarjetas que giran al tocarlas, audio en inglés, práctica de pronunciación y botones «La sé / Casi / Necesito repasarla». |
| **Jugar** | 8 modos: elección múltiple, traducir al español, traducir al inglés, completar la palabra, emparejar, ordenar letras, contrarreloj (60 s) y reto diario. |
| **Progreso** | Palabras aprendidas y pendientes, racha, precisión, tiempo estudiado, gráfico de 7 días y 14 medallas. |
| **Ajustes** (⚙️ en Inicio) | Objetivo diario (5/10/20/30), tamaño de sesión, velocidad de voz, lectura automática, tema claro/oscuro, recordatorio diario y reinicio del progreso. |

### Repetición espaciada (sistema Leitner)
Cada palabra está en una «caja» del 0 al 7:

- **La sé** → sube una caja y vuelve en 1, 2, 4, 8, 16, 32 o 64 días.
- **Casi** → se queda en su caja y vuelve en la mitad de tiempo.
- **Necesito repasarla** → vuelve a la caja 0 y sale otra vez al final de la sesión.
- Fallar en un juego baja la palabra una caja y la deja pendiente para hoy.
- A partir de la **caja 3** la palabra cuenta como **aprendida**.

Los repasos muestran primero las palabras más flojas y más atrasadas.

### Puntos y niveles
+10 XP por acierto (7 por «Casi», 2 por intentarlo) y **+50 XP** al cumplir el objetivo diario. Los niveles van de *Principiante* a *Leyenda*.

---

## Qué formato de PDF funciona mejor

El PDF debe tener **texto seleccionable** (si puedes seleccionar una palabra con el dedo en un lector de PDF, sirve). Los PDF escaneados (fotos) no tienen texto: en ese caso copia el texto y usa **«Pegar o escribir palabras»**.

**1. Tabla con encabezado (lo mejor).** Reconoce columnas llamadas *Inglés / English*, *Español / Spanish / Traducción*, *Pronunciación* y *Tema* (en cualquier orden; pronunciación y tema son opcionales):

| Inglés | Español | Pronunciación | Tema |
|---|---|---|---|
| airport | aeropuerto | /ˈeəpɔːt/ | Viajes |
| kitchen | cocina | /ˈkɪtʃɪn/ | Casa |

**2. Una palabra por línea con separador.** Valen `-`, `–`, `=`, `→`, `:`, `;` o `|`:

```
house - casa
to run = correr
Good morning: Buenos días
luggage /ˈlʌɡɪdʒ/ → equipaje
```

- Números y viñetas al principio (`1.`, `•`, `-`) se ignoran.
- Una línea corta acabada en dos puntos (`Animales:`) se usa como **tema** de las siguientes.
- La pronunciación entre `/barras/` o `[corchetes]` se detecta sola.
- Si las columnas vienen al revés (español – inglés), la app lo detecta y las invierte.

**3. Líneas alternas** (inglés en una línea, español en la siguiente): tras importar, pulsa **«Emparejar líneas alternas»**.

Antes de guardar siempre verás una **pantalla de revisión** para corregir, borrar o añadir palabras, elegir el nombre de la lista o añadirlas a una lista existente.

En la carpeta `ejemplos/` tienes `vocabulario_ejemplo.pdf` para probar.

---

## Cómo añadir vocabulario

- **Desde un PDF:** *Mis listas* → **Importar PDF**. También puedes abrir un PDF desde el gestor de archivos o WhatsApp con *Abrir con… / Compartir → VocaPDF*.
- **Pegando texto:** *Mis listas* → **Nueva lista pegando o escribiendo palabras**.
- **A mano:** entra en una lista y pulsa **+**. Toca cualquier palabra para editarla o borrarla.
- **Ampliar una lista:** al importar, elige «Añadir a «Viajes»» en lugar de crear una lista nueva.
- **Desde Excel o Google Sheets:** guarda como CSV y usa *Mis listas → Importar CSV* (ver abajo).

---

## Copias de seguridad y CSV

**Exportar**
- *Ajustes → Datos → Exportar CSV*: guarda **todas** las listas con su **progreso** (caja, próximo repaso, aciertos…). Puedes guardarlo en Drive, en Descargas o enviártelo por correo.
- Dentro de una lista, el icono ⬇️ exporta solo esa lista.

**Importar**
- *Mis listas → Importar CSV* o *Ajustes → Datos → Importar CSV*.
- Si el archivo tiene columna `lista`, cada palabra va a su lista (se crea si no existe). Si no la tiene, todo va a una lista con el nombre del archivo.
- Las palabras repetidas se omiten, así que puedes importar la misma copia varias veces sin duplicar nada.
- Si el CSV trae el progreso, se recupera tal cual: ideal para **pasar la app a otro móvil**.

**Formato** (UTF-8, separado por `;`, se abre directamente en Excel en español):

```
lista;ingles;espanol;pronunciacion;tema;caja;proximo_repaso;repasos;aciertos;fallos;dificultad
Viajes;airport;aeropuerto;ˈeəpɔːt;Viajes;3;2026-11-08T00:00;5;4;1;1
```

Solo `ingles` y `espanol` son obligatorias. También vale un CSV hecho a mano en Excel o Google Sheets con dos columnas *Inglés* y *Español* (separadas por `;`, `,` o tabulador). Sin encabezado, la 1.ª columna se toma como inglés y la 2.ª como español. Tienes un ejemplo en `ejemplos/vocabulario_ejemplo.csv`.

---

## Compilar e instalar

### Opción A · Sin instalar nada (GitHub, recomendado)
1. Crea una cuenta gratuita en github.com y un repositorio nuevo.
2. Sube el contenido de esta carpeta (botón *Add file → Upload files*, arrastrando todo, **incluida la carpeta oculta `.github`**).
3. Ve a la pestaña **Actions**: la compilación «Compilar APK» se lanza sola (unos 5–8 minutos).
4. Al terminar, abre la ejecución y descarga **VocaPDF-apk** (un .zip con el `.apk`).
5. Pasa el `.apk` al móvil y ábrelo. Android te pedirá permitir **«Instalar apps desconocidas»** para esa app (Ajustes → Seguridad). Acepta e instala.

### Opción B · Con Android Studio
1. Instala **Android Studio** (versión Koala 2024.1 o posterior).
2. *File → Open* y elige la carpeta `VocaPDF`. Espera a que termine la sincronización de Gradle (la primera vez descarga dependencias).
3. En el móvil: *Ajustes → Información del teléfono* → toca 7 veces «Número de compilación» para activar las **Opciones de desarrollador**, y allí activa **Depuración USB**.
4. Conecta el móvil por USB, selecciónalo arriba y pulsa ▶ **Run**.
5. Para generar un `.apk`: *Build → Build App Bundle(s) / APK(s) → Build APK(s)*. Queda en `app/build/outputs/apk/`.

### Desde la terminal
```bash
./gradlew testDebugUnitTest   # tests de la lógica (PDF, CSV, repasos, niveles)
./gradlew assembleDebug       # APK de prueba en app/build/outputs/apk/debug/
./gradlew installDebug        # instala en el móvil conectado por USB
```
Requiere JDK 17 y el Android SDK (Android Studio lo instala).

> El APK *release* se firma con la clave de depuración para poder instalarlo directamente. Si algún día quieres publicarlo en Google Play, crea tu propia clave de firma.

**Requisitos del móvil:** Android 8.0 o superior.

---

## Voz y pronunciación

- El audio usa el **motor de texto a voz del móvil**. Para que funcione sin Internet, descarga la voz en inglés: *Ajustes de la app → Voz → Descargar voces*.
- El botón 🎙️ usa el **reconocimiento de voz del sistema** (normalmente el de Google). Si tu móvil no lo tiene, el botón no aparece. Con el paquete de idioma inglés descargado funciona sin conexión.
- La valoración es amable: «¡Perfecto!», «¡Muy bien! Casi perfecto», «¡Buen intento!»… y te enseña lo que ha entendido.

## Permisos
Solo uno, y solo si activas los recordatorios: **notificaciones** (Android 13+). No pide Internet, micrófono, cuenta ni ubicación.

---

## Estructura del proyecto

```
VocaPDF/
├─ app/src/main/java/es/vocapdf/app/
│  ├─ VocaApp.kt              Arranque y dependencias compartidas
│  ├─ MainActivity.kt         Actividad única; recibe PDFs de otras apps
│  ├─ pdf/
│  │  ├─ PdfTextExtractor.kt  Extrae texto con PDFBox y marca las columnas
│  │  └─ VocabParser.kt       Detecta pares inglés–español, tablas, temas
│  ├─ data/
│  │  ├─ db/Database.kt       Room: listas, palabras+progreso, historial, estadísticas
│  │  ├─ backup/CsvBackup.kt  Lectura y escritura de CSV (copias de seguridad)
│  │  ├─ VocabRepository.kt   Acceso a datos, XP, objetivo diario, resumen
│  │  └─ SettingsRepository.kt Ajustes (DataStore)
│  ├─ domain/
│  │  ├─ Srs.kt               Sistema Leitner
│  │  ├─ Gamification.kt      Niveles, rachas, medallas, mensajes
│  │  └─ TextMatch.kt         Corrección flexible (tildes, erratas, alternativas)
│  ├─ audio/                  Voz (TTS) y reconocimiento de pronunciación
│  ├─ reminders/              Recordatorio diario (WorkManager + notificación)
│  └─ ui/                     Pantallas en Jetpack Compose
│     ├─ home/ decks/ importer/ study/ games/ progress/ settings/
│     ├─ components/          Botones, tarjetas y selectores comunes
│     └─ theme/               Colores (modo claro y oscuro)
├─ app/src/test/              Tests de la lógica
├─ ejemplos/                  PDF de ejemplo
└─ .github/workflows/         Compilación automática del APK
```

### Base de datos (Room · `vocapdf.db`)
| Tabla | Contenido |
|---|---|
| `decks` | Listas: nombre, fecha, PDF de origen |
| `words` | Inglés, español, pronunciación, tema **y progreso**: caja, próxima fecha, repasos, aciertos, fallos, dificultad |
| `review_log` | Cada respuesta: palabra, día, modo, acierto |
| `daily_stats` | Por día: repasos, aciertos, segundos, XP, objetivo cumplido, puntuación del reto |

### Tecnología
Kotlin 2.0 · Jetpack Compose (Material 3) · Room · DataStore · WorkManager · Navigation Compose · [PdfBox-Android](https://github.com/TomRoush/PdfBox-Android) (Apache 2.0) · TextToSpeech y RecognizerIntent nativos.

### Ideas para ampliar
- Frases de ejemplo por palabra.
- OCR con ML Kit para PDFs escaneados.
